package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s58 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s58_layout);

        ListView s58 = (ListView) findViewById(R.id.s58_layout);
        final String[] topic = {"1. Study of various types of robots",
                "2. Programming the Hitech robot manipulator",
                "3. Programming of Fanuc M 710i robot",
                "4. Programming of Adept Cobra S 600 SCARA robot",
                "5. Programming of Adept Quattro S 650 Parallel kinematic robot",
                "6. Programming Lego NXT",
                "7. Programming and assembling of a Lego Mindstorm",
                "8. Programming the hexapod for different movements",
                "9. Programming on Tetrix",
                "10. Programming in RoS"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s58.this, android.R.layout.simple_list_item_1, topic);

        s58.setAdapter(adapter31);

    }
}
