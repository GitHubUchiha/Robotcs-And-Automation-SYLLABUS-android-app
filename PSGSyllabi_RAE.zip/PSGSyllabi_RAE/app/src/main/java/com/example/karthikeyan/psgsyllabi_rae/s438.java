package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s438 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s438_layout);

        ListView s438 = (ListView) findViewById(R.id.s438_layout);
        final String[] topic = {"1. Steve F Krar, “Computer Numerical Control Simplified“, Industrial Press, 2001",
        "2. Radhakrishnan P., Computer Numerical Control Machines, New Central Book Agency,1992"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s438.this, android.R.layout.simple_list_item_1, topic);

        s438.setAdapter(adapter31);

    }
}