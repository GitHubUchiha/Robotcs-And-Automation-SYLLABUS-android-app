package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s657 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s657_layout);

        ListView s657 = (ListView) findViewById(R.id.s657_layout);
        final String[] topic = {"Terms of Trade" , "Balance of Payments" , "Exchange rate determination" , "Methods of foreign payments" , "International Institutions" , "IMF", "IBRD"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s657.this, android.R.layout.simple_list_item_1, topic);

        s657.setAdapter(adapter31);

    }
}