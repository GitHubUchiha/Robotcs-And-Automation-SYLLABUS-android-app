package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s59 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s59_layout);

        ListView s59 = (ListView) findViewById(R.id.s59_layout);
        final String[] topic = {"Students have to do a Mechatronics project based on their idea. It can be a modeling, simulation, design or hardware project."};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s59.this, android.R.layout.simple_list_item_1, topic);

        s59.setAdapter(adapter31);

    }
}
