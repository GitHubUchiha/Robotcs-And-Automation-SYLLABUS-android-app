package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s466 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s466_layout);

        ListView s466 = (ListView) findViewById(R.id.s466_layout);
        final String[] topic = {"1. Arthur P. Boresi and Richard J. Schmidt, “ Engineering mechanics: statics” , Brooks/Cole, CA, USA,2001",
        "2. Arthur P. Boresi and Richard J. Schmidt, “ Engineering mechanics: Dynamics” , Brooks/Cole, CA, USA, 2001",
        "3. Shigley J E and Uicker J J, “Theory of Machines and Mechanisms”, McGraw Hill , New Delhi, 1996"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s466.this, android.R.layout.simple_list_item_1, topic);

        s466.setAdapter(adapter31);

    }
}