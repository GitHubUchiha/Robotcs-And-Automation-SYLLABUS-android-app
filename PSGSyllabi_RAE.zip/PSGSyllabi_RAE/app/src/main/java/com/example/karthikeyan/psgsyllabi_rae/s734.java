package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s734 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s734_layout);

        ListView s734 = (ListView) findViewById(R.id.s734_layout);
        final String[] topic = {"Proprietary and open Protocols" , "OLE/OPC" , "DDE" , "Server/Client Configuration" , "Messaging" , "Recipe" , "User administration" , "Interfacing of SCADA with PLC, drive, and other field device" };

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s734.this, android.R.layout.simple_list_item_1, topic);

        s734.setAdapter(adapter31);

    }
}