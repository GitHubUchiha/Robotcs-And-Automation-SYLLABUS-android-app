package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s321 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s321_layout);

        ListView s321 = (ListView) findViewById(R.id.s321_layout);
        final String[] topic = {"Computer codes – BCD, Gray code, Excess 3 code", "Error detection and correction codes", "Parity, Hamming codes", "Boolean algebra – Basic Postulates and theorems", "Switching functions", "Canonical forms", "Logic gates"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s321.this, android.R.layout.simple_list_item_1, topic);

        s321.setAdapter(adapter31);

    }
}