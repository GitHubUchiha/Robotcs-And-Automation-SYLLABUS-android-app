package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s62 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s62_layout);

        ListView s62 = (ListView) findViewById(R.id.s62_layout);
        final String[] topic = {"INTRODUCTION TO EMBEDDED SYSTEM","EMBEDDED SYSTEMS CHARACTERISTICS","EMBEDDED SYSTEM ARCHITECTURE","EMBBEDDED SOFTWARE ARCHITECTURE","REAL TIME OPERATING SYSTEMS","DESIGN USING RTOS","EMBEDDED SOFTWARE DEVELOPMENT TOOLS","TEXT BOOKS","REFERENCES"};


        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s62.this, android.R.layout.simple_list_item_1, topic);

        s62.setAdapter(adapter31);
        s62.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s62.this, s621.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s62.this, s622.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s62.this, s623.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s62.this, s624.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s62.this, s625.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s62.this, s626.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s62.this, s627.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s62.this, s628.class);
                    startActivity(intent);
                }
                if (position == 8) {
                    Intent intent = new Intent(s62.this, s629.class);
                    startActivity(intent);
                }

            }
        });

    }
}