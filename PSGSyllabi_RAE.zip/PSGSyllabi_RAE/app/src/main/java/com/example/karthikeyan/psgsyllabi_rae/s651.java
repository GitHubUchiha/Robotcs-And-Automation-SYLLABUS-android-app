package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s651 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s651_layout);

        ListView s651 = (ListView) findViewById(R.id.s651_layout);
        final String[] topic = {"Definition" , "Nature" , "Scope and Significance of Economics for Engineers"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s651.this, android.R.layout.simple_list_item_1, topic);

        s651.setAdapter(adapter31);

    }
}