package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s432 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s432_layout);

        ListView s432 = (ListView) findViewById(R.id.s432_layout);
        final String[] topic = {"Types and constructional features of machine tools", "Turning centres", "machining centres", "grinding machines", "EDMs", "turret punch press", "laser and water jet cutting machines", "Design considerations" , "Axis representations", "Various operating modes of a CNC machine"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s432.this, android.R.layout.simple_list_item_1, topic);

        s432.setAdapter(adapter31);

    }
}