package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s351 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s351_layout);

        ListView s351 = (ListView) findViewById(R.id.s351_layout);
        final String[] topic = {"Constructional details", "EMF equation", "methods of excitation", "self and separately excited generators", "characteristics of series, and shunt generators" ,"principle of operation of D.C. Motor", "back emf and torque equation", "characteristics of series and shunt motors" , "starting of D.C. Motors – types of starters - speed control and braking of DC motors"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s351.this, android.R.layout.simple_list_item_1, topic);

        s351.setAdapter(adapter31);

    }
}