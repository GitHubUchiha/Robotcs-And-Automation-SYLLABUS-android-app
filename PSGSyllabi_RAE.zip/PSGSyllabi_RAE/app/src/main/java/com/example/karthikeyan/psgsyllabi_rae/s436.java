package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s436 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s436_layout);

        ListView s436 = (ListView) findViewById(R.id.s436_layout);
        final String[] topic = {"Axis notation", "EIA and ISO codes", "Explanation of basic codes", "Tooling concepts", "machining methods", "part geometry and writing of tool motion statements" ,"Canned cycles", "Development of simple manual part programs for turning operations", "Simulation of part programmes", "Post processors - CNC part programming with CAD/CAM systems"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s436.this, android.R.layout.simple_list_item_1, topic);

        s436.setAdapter(adapter31);

    }
}