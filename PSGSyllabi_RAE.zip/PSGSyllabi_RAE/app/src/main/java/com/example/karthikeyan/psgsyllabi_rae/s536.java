package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s536 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s536_layout);

        ListView s536 = (ListView) findViewById(R.id.s536_layout);
        final String[] topic = {"Trajectory planning and avoidance of obstacles", "path planning", "skew motion", "joint integrated motion" , "straight line motion-Robot languages" ,"computer control and Robot software"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s536.this, android.R.layout.simple_list_item_1, topic);

        s536.setAdapter(adapter31);

    }
}