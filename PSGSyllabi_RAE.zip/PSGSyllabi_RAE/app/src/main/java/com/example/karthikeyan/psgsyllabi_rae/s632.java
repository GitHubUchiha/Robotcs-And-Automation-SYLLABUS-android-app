package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s632 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s632_layout);

        ListView s632 = (ListView) findViewById(R.id.s632_layout);
        final String[] topic = {"Fundamental Data Structures:", "Images", "Regions", "Sub-pixel Precise Contours" , "Image Enhancement :", "Gray value transformations", "image smoothing", "Fourier Transform" , "Geometric Transformation" , "Image segmentation" , "Segmentation of contours", "lines", "circles and ellipses" , "Camera calibration" , "Stereo Reconstruction"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s632.this, android.R.layout.simple_list_item_1, topic);

        s632.setAdapter(adapter31);

    }
}