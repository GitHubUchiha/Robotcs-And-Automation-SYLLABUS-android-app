package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s652 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s652_layout);

        ListView s652 = (ListView) findViewById(R.id.s652_layout);
        final String[] topic = {"Demand" , "Types" , "Determinants" , "Law of Demand" , "Elasticity of Demand" , "Types" , "Significance" ,"Supply" , "Market price determination" , "Case Study in Demand Forecasting" ,"Meaning" , "Methods", "Consumer Survey" , "Trend Projections" , "Moving average"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s652.this, android.R.layout.simple_list_item_1, topic);

        s652.setAdapter(adapter31);

    }
}