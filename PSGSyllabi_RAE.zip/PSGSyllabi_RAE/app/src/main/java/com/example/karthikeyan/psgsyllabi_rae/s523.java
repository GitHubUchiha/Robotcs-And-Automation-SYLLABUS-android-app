package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s523 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s523_layout);

        ListView s523 = (ListView) findViewById(R.id.s523_layout);
        final String[] topic = {"Types of Programming" , "Simple process control programs using Relay Ladder Logic" , "PLC arithmetic functions" , "Timers and counters" ,"data transfer-comparison and manipulation instructions", "PID instructions", "PTO / PWM generation"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s523.this, android.R.layout.simple_list_item_1, topic);

        s523.setAdapter(adapter31);

    }
}