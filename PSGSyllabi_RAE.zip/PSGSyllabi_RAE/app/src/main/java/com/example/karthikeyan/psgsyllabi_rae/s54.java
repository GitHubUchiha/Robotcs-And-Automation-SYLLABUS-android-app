package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s54 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s54_layout);

        ListView s54 = (ListView) findViewById(R.id.s54_layout);
        final String[] topic = {"ARCHITECTURE OF 8085 MICROPROCESSOR","PROGRAMMING OF 8085","MEMORY INTERFACING","I/O INTERFACING","INTERRUPTS AND DMA","APPLICATIONS","INTEL 8051 MICROCONTROLLER","8051 PERIPHERALS","TEXT BOOKS","REFERENCES"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s54.this, android.R.layout.simple_list_item_1, topic);

        s54.setAdapter(adapter31);
        s54.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s54.this, s541.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s54.this, s542.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s54.this, s543.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s54.this, s544.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s54.this, s545.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s54.this, s546.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s54.this, s547.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s54.this, s548.class);
                    startActivity(intent);
                }
                if (position == 8) {
                    Intent intent = new Intent(s54.this, s549.class);
                    startActivity(intent);
                }
                if (position == 9) {
                    Intent intent = new Intent(s54.this, s549.class);
                    startActivity(intent);
                }
               

            }
        });

    }
}