package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s733 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s733_layout);

        ListView s733 = (ListView) findViewById(R.id.s733_layout);
        final String[] topic = {"overview" , "Developer and runtime packages" , "architecture" , "Tools" , "Tag" , "Internal &External graphics", "Alarm logging" , "Tag logging" , "structured tags", "Trends" , "history", "Report generation, VB & C Scripts for SCADA application"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s733.this, android.R.layout.simple_list_item_1, topic);

        s733.setAdapter(adapter31);

    }
}