package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s613 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s613_layout);

        ListView s613 = (ListView) findViewById(R.id.s613_layout);
        final String[] topic = {"Voltage Source inverters" ,"bridge inverters", "Current source inverters" , "voltage and waveform control of inverters", "DC choppers – step up and step down – uninterrupted power supplies"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s613.this, android.R.layout.simple_list_item_1, topic);

        s613.setAdapter(adapter31);

    }
}