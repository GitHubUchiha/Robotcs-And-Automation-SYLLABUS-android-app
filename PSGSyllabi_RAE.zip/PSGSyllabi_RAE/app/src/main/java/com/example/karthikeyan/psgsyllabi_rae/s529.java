package com.example.karthikeyan.psgsyllabi_rae;

        import android.app.Activity;
        import android.os.Bundle;
        import android.widget.ArrayAdapter;
        import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s529 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s529_layout);

        ListView s529 = (ListView) findViewById(R.id.s529_layout);
        final String[] topic = {"1. Wire up a PLC for the given lamp circuit",
                "2. Design a Ladder logic for the given lamp circuit",
                "3. Design and implement ladder logic for the forward and reverse control of a hydraulic cylinder.",
                "4. Design a ladder diagram for performing the given arithmetic operations.",
                "5. Design a ladder diagram for performing the given application using counters",
                "6. Design a ladder diagram for performing the given application using Timers",
                "7. Interfacing PLC to HMI- text display",
                "8. Programming a graphical HMI",
                "9. Networking PLCs- drives and a host computer",
                "10. Troubleshooting PLCs"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s529.this, android.R.layout.simple_list_item_1, topic);

        s529.setAdapter(adapter31);

    }
}