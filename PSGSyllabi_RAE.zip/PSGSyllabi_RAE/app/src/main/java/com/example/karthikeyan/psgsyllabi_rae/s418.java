package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s418 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s418_layout);

        ListView s418 = (ListView) findViewById(R.id.s418_layout);
        final String[] topic = {"1. Roy D.Yates and David J Goodman, “ Probability and Stochastic Processes – A friendly Introduction for Electrical and ComputerEngineers”, John Wiley & Sons, 2005",
        "2. Athanasios Papoulis and S.Unnikrishna Pillai,“Probability, Random Variables and Stochastic Processes”, McGraw Hill, 2002."};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s418.this, android.R.layout.simple_list_item_1, topic);

        s418.setAdapter(adapter31);

    }
}