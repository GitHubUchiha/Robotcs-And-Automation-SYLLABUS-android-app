package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s312 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s312_layout);

        ListView s312 = (ListView) findViewById(R.id.s312_layout);
        final String[] topic = {"computer arithmetic and errors"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s312.this, android.R.layout.simple_list_item_1, topic);

        s312.setAdapter(adapter31);

    }
}
