package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s557 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s557_layout);

        ListView s557 = (ListView) findViewById(R.id.s557_layout);
        final String[] topic = {"1. Bandari V B, 'Design of Machine Elements ', Tata McGraw Hill Publishers Co. Ltd., New Delhi, 2003",
                "2. Robert L Nortan, “Machine Design-An Integrated Approach”, Pearson Publishers, New Delhi, 2003.",
        "3. Maitra G M, “Handbook of Gear Design”, Tata McGraw Hill, New Delhi, 1998",
        "4. Faculty of Mechanical Engineering, PSG College of Technology, 'Design Data Book', M/s. DPV Printers, Coimbatore, 2000"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s557.this, android.R.layout.simple_list_item_1, topic);

        s557.setAdapter(adapter31);

    }
}