package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s528 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s528_layout);

        ListView s528 = (ListView) findViewById(R.id.s528_layout);
        final String[] topic = {"1. W. Bolton, “Mechatronics”, Pearson Education, 2009",
        "2. Kelvin T Erikson, 'Programmable Logic Controllers', Dogwood Valley Press, 2005"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s528.this, android.R.layout.simple_list_item_1, topic);

        s528.setAdapter(adapter31);

    }
}