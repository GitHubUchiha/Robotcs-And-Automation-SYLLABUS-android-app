package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s356 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s356_layout);

        ListView s356 = (ListView) findViewById(R.id.s356_layout);
        final String[] topic = {"1. K. Murugesh Kumar, ‘Electric Machines Vo I’, Vikas Publishing House Pvt Ltd, 2010.",
        "2. K. Murugesh Kumar, ‘Electric Machines Vol II’, Vikas Publishing House Pvt Ltd, 2010",
        "3. V.K.Mehta and Rohit Mehta, ‘Principles of Power System’, S.Chand and Company Ltd, 2003"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s356.this, android.R.layout.simple_list_item_1, topic);

        s356.setAdapter(adapter31);

    }
}