package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s331 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s331_layout);

        ListView s331 = (ListView) findViewById(R.id.s331_layout);
        final String[] topic = {"Factors in making the measurements-accuracy", "precision", "resolution", "repeatability", "reproducibility", "hysteresis", "sensitivity", "range", "International standards for measurement", "Errors in Measurement – Gross Errors", "Systematic Errors", "Mounting and deformation Error – Thermally Induced Error – Interpolation Error – Dynamic Error", "Calibration techniques"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s331.this, android.R.layout.simple_list_item_1, topic);

        s331.setAdapter(adapter31);

    }
}
