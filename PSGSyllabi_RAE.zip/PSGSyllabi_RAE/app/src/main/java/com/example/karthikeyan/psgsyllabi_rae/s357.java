package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s357 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s357_layout);

        ListView s357 = (ListView) findViewById(R.id.s357_layout);
        final String[] topic = {"1. A.E. Fitzgerald, Charles Kingsley, Stephen.D.Umans, ‘Electric Machinery’, Tata McGraw Hill publishing Company Ltd, 2003.",
        "2. J.B. Gupta, ‘Theory and Performance of Electrical Machines’, S.K.Kataria and Sons, 2002",
        "3. D.P. Kothari and I.J. Nagrath, ‘Electric Machines’, Tata McGraw Hill Publishing Company Ltd, 2002",
        "4. P.S. Bhimbhra, ‘Electrical Machinery’, Khanna Publishers, 2003."};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s357.this, android.R.layout.simple_list_item_1, topic);

        s357.setAdapter(adapter31);

    }
}