package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s65 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s65_layout);

        ListView s65 = (ListView) findViewById(R.id.s65_layout);
        final String[] topic = {"INTRODUCTION","DEMAND AND SUPPLY","COST AND REVENUE","MARKET STRUCTURE","MARKET FAILURE","MONEY AND BANKING","FOREIGN EXCHANGE","BUSINESS CYCLE AND NATIONAL INCOME","TEXT BOOKS","REFERENCES"};


        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s65.this, android.R.layout.simple_list_item_1, topic);

        s65.setAdapter(adapter31);
        s65.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s65.this, s651.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s65.this, s652.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s65.this, s653.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s65.this, s654.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s65.this, s655.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s65.this, s656.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s65.this, s657.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s65.this, s658.class);
                    startActivity(intent);
                }
                if (position == 8) {
                    Intent intent = new Intent(s65.this, s659.class);
                    startActivity(intent);
                }
                if (position == 9) {
                    Intent intent = new Intent(s65.this, s6510.class);
                    startActivity(intent);
                }



            }
        });

    }
}
