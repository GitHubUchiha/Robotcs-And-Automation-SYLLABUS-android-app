package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s549 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s549_layout);

        ListView s549 = (ListView) findViewById(R.id.s549_layout);
        final String[] topic = {"1. Ramesh S Goankar, “Microprocessor Architecture: Programming and Applications with the 8085 “,Penram International, 2000.", "2. Mazidi Muhammed Ali, MazidiJanice Gillispie, 'The 8051 Microcontroller and Embedded Systems', Pearson Education India, 2000"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s549.this, android.R.layout.simple_list_item_1, topic);

        s549.setAdapter(adapter31);

    }
}