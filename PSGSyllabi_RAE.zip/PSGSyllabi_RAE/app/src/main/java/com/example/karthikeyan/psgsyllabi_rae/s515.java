package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s515 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s515_layout);

        ListView s515 = (ListView) findViewById(R.id.s515_layout);
        final String[] topic = {"Replacement of items that deteriorate" , "replacement of items that fail", "group replacement"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s515.this, android.R.layout.simple_list_item_1, topic);

        s515.setAdapter(adapter31);

    }
}