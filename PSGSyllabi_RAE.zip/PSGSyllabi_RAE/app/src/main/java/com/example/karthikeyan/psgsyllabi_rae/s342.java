package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10,02,2016.
 */
public class s342 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s342_layout);

        ListView s342 = (ListView) findViewById(R.id.s342_layout);
        final String[] topic = {"Symbols", "Transistor construction and operation" , "characteristics of CB, CC and CE configurations", "Transistor amplifying action" , "Limits of operation" , "Transistor biasing:", "Operating point", "load line analysis of fixed bias circuit" , "cascade connection, cascode connection and Darlington connection"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s342.this, android.R.layout.simple_list_item_1, topic);

        s342.setAdapter(adapter31);

    }
}

