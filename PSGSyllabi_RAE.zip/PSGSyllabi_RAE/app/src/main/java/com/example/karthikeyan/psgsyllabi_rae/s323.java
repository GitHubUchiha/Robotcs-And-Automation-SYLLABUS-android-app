package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s323 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s323_layout);

        ListView s323 = (ListView) findViewById(R.id.s323_layout);
        final String[] topic = {"Binary / BCD adders and subtractors", "Carry look ahead adder", "Magnitude comparator", "ALU"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s323.this, android.R.layout.simple_list_item_1, topic);

        s323.setAdapter(adapter31);

    }
}
