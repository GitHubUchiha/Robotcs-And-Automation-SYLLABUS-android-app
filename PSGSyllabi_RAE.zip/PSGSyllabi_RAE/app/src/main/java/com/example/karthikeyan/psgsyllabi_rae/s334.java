package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s334 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s334_layout);

        ListView s334 = (ListView) findViewById(R.id.s334_layout);
        final String[] topic = {"Linear and angular measurement systems", "Potentiometer type- resistive- strain gauge", "capacitive and inductive", "LVDT", "Limit switches", "inductive and capacitive proximity switches", "ultrasonic and photo-electric sensors- linear scales", "Laser Interferometers, tachogenerator", "Encoders-absolute and incremental" ,"Synchros and resolvers"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s334.this, android.R.layout.simple_list_item_1, topic);

        s334.setAdapter(adapter31);

    }
}