package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s514 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s514_layout);

        ListView s514 = (ListView) findViewById(R.id.s514_layout);
        final String[] topic = {"Characteristics of queuing systems ", "Steady state M/M/1, M/M/1/K, and M/M/C Queuing models"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s514.this, android.R.layout.simple_list_item_1, topic);

        s514.setAdapter(adapter31);

    }
}