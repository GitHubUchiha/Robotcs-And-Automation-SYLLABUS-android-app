package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s355 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s355_layout);

        ListView s355 = (ListView) findViewById(R.id.s355_layout);
        final String[] topic = {"Structure of electric power systems" , "generation", "transmission", "sub-transmission and distribution systems" , "EHVAC and EHVDC transmission systems" , "substation layout. (Concepts only)"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s355.this, android.R.layout.simple_list_item_1, topic);

        s355.setAdapter(adapter31);

    }
}