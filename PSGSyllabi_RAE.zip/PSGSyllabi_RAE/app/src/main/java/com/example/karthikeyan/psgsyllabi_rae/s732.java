package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s732 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s732_layout);

        ListView s732 = (ListView) findViewById(R.id.s732_layout);
        final String[] topic = {"Necessity and Role in Industrial Automation", "Need for HMI systems", "Types of HMI", "Text display" , "operator panels" , "Touch panels" , "Panel PCs" , "Integrated displays (PLC & HMI)", "Check with PLC 502 and remove" };

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s732.this, android.R.layout.simple_list_item_1, topic);

        s732.setAdapter(adapter31);

    }
}