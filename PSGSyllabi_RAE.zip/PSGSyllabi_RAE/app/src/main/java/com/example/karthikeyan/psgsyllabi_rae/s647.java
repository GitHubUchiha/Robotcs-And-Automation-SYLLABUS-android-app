package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s647 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s647_layout);

        ListView s647 = (ListView) findViewById(R.id.s647_layout);
        final String[] topic = {"Stages in design", "traditional and mechatronic design", "possible design solutions", "Case studies-pick and place robot", "engine management system"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s647.this, android.R.layout.simple_list_item_1, topic);

        s647.setAdapter(adapter31);

    }
}