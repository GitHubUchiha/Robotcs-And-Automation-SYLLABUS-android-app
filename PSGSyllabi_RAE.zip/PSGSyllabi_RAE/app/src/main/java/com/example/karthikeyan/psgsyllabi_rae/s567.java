package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s567 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s567_layout);

        ListView s567 = (ListView) findViewById(R.id.s567_layout);
        final String[] topic = {"1. Morris Mano M, 'Computer System Architecture', Prentice Hall of India ,New Delhi, 2000. Pearson Education, New Delhi"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s567.this, android.R.layout.simple_list_item_1, topic);

        s567.setAdapter(adapter31);

    }
}