package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class SecondActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.year);
        ListView year = (ListView)findViewById(R.id.year);

        final String[] yr = {"SMESTER 3","SMESTER 4","SMESTER 5","SMESTER 6","SMESTER 7","SMESTER 8"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(SecondActivity.this,android.R.layout.simple_list_item_1,yr);

        year.setAdapter(adapter);

        year.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                
                    if(position==0) {
                        Intent intent3 = new Intent(SecondActivity.this, s3.class);
                        startActivity(intent3);

                    }
                    if(position==1) {
                        Intent intent4 = new Intent(SecondActivity.this, s4.class);
                        startActivity(intent4);
                    }
                    if(position==2) {
                        Intent intent5 = new Intent(SecondActivity.this,s5.class);
                        startActivity(intent5);
                        }
                    if(position==3) {
                        Intent intent6 = new Intent(SecondActivity.this,s6.class);
                        startActivity(intent6);
                        }
                    if(position==4) {
                        Intent intent7 = new Intent(SecondActivity.this,s7.class);
                        startActivity(intent7);
                        }
                    if(position==5) {
                        Intent intent8 = new Intent(SecondActivity.this,s8.class);
                        startActivity(intent8);
                        }


                }

        });

    }
}
