package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s344 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s344_layout);

        ListView s344 = (ListView) findViewById(R.id.s344_layout);
        final String[] topic = {"Small signal models and h-parameter model of a BJT", "Power amplifiers:", "Characteristics and power relationship of Class-A amplifier", "transformer couple Class-A amplifier and Class-B amplifier","Class-B push-pull amplifier"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s344.this, android.R.layout.simple_list_item_1, topic);

        s344.setAdapter(adapter31);

    }
}

