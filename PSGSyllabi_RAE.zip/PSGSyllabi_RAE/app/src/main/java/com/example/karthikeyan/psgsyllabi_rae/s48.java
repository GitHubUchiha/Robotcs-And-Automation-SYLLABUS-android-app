package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s48 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s48_layout);

        ListView s48 = (ListView) findViewById(R.id.s48_layout);
        final String[] topic = {"1. Static and dynamic balancing using rotating unbalance test rig","2. Preparation of cam displacement curve and determination of jump speed of a cam","3. Determination of natural frequencies of transverse and torsional vibrations","4. Measurement of friction and wear","5. Determination of moment of inertia of connecting rod and validation using software","6. Free fall drop impact testing for hand held product","7. Dynamic balance of machine elements","8. Moment of Inertia of the Gyroscope Disc"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s48.this, android.R.layout.simple_list_item_1, topic);

        s48.setAdapter(adapter31);

    }
}
