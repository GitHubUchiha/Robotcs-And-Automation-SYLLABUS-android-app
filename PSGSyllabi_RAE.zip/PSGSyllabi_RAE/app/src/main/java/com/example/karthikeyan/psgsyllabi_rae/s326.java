package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s326 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s326_layout);

        ListView s326 = (ListView) findViewById(R.id.s326_layout);
        final String[] topic = {"Semicustom design", "Introduction to PLDs – ROM", "PAL", "PLA", "FPLA", "Architecture of PLDs – PAL 22V10"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s326.this, android.R.layout.simple_list_item_1, topic);

        s326.setAdapter(adapter31);

    }
}