package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s458 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s458_layout);

        ListView s458 = (ListView) findViewById(R.id.s458_layout);
        final String[] topic = {"1. Coughlin F R, and Driscoll F F, “Operational Amplifiers and Linear Integrated Circuits”, Prentice Hall of India, New Delhi, 1997", "2. Roy Choudhury and Shail Jain, “Linear Integrated Circuits”, New Age International Limited, 2003"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s458.this, android.R.layout.simple_list_item_1, topic);

        s458.setAdapter(adapter31);

    }
}