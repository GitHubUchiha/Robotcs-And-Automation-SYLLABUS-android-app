package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s641 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s641_layout);

        ListView s641 = (ListView) findViewById(R.id.s641_layout);
        final String[] topic = {"Fundamental concepts in manufacturing and automation", "definition of automation", "reasons for automating" ,"Types of production and types of automation", "automation strategies", "levels of automation"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s641.this, android.R.layout.simple_list_item_1, topic);

        s641.setAdapter(adapter31);

    }
}