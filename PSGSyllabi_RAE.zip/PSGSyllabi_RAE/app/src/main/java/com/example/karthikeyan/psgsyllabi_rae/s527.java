package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s527 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s527_layout);

        ListView s527 = (ListView) findViewById(R.id.s527_layout);
        final String[] topic = {"1. John W Webb & Ronald A Reis, “Programmable logic controllers: Principles and Applications”, Prentice Hall India, 2003",
        "2. Frank D Petruzella 'Programmable Logic Controllers', McGraw Hill Inc, 2005"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s527.this, android.R.layout.simple_list_item_1, topic);

        s527.setAdapter(adapter31);

    }
}