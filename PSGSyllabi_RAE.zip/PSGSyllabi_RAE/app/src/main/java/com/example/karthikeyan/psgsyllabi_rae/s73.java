package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s73 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s73_layout);

        ListView s73 = (ListView) findViewById(R.id.s73_layout);
        final String[] topic = {"TOTALLY INTEGRATED AUTOMATION","HMI SYSTEMS","SUPERVISORY CONTROL AND DATA ACQUISITION (SCADA)","COMMUNICATION PROTOCOLS of SCADA","DISTRIBUTED CONTROL SYSTEMS (DCS)","APPLICATIONS OF PLC & DCS","TEXT BOOKS","REFERENCES"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s73.this, android.R.layout.simple_list_item_1, topic);

        s73.setAdapter(adapter31);
        s73.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s73.this, s731.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s73.this, s732.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s73.this, s733.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s73.this, s734.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s73.this, s735.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s73.this, s736.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s73.this, s737.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s73.this, s738.class);
                    startActivity(intent);
                }


            }
        });

    }
}
