package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s324 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s324_layout);

        ListView s324 = (ListView) findViewById(R.id.s324_layout);
        final String[] topic = {"General model of sequential circuits – Latch, Flip Flops", "Level triggering", "Edge triggering", "Master slave configuration", "Binary counters", "Shift register", "Ring counter", "Johnson counter"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s324.this, android.R.layout.simple_list_item_1, topic);

        s324.setAdapter(adapter31);

    }
}
