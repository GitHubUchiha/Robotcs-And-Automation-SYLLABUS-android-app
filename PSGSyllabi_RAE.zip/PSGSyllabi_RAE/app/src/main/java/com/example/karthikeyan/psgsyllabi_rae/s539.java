package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s539 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s539_layout);

        ListView s539 = (ListView) findViewById(R.id.s539_layout);
        final String[] topic = {"1. Richard D Klafter, Thomas A Chmielewski, Michael Negin, 'Robotics Engineering – An Integrated Approach', Eastern Economy Edition, Prentice Hall of India P Ltd., 2006.",
                "2. Fu K S, Gonzalez R C, Lee C.S.G, 'Robotics : Control, Sensing, Vision and Intelligence', McGraw Hill, 1987"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s539.this, android.R.layout.simple_list_item_1, topic);

        s539.setAdapter(adapter31);

    }
}