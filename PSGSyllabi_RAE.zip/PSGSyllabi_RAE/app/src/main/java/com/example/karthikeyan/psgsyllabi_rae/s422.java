package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s422 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s422_layout);

        ListView s422 = (ListView) findViewById(R.id.s422_layout);
        final String[] topic = {"Standard Test signals" , "Time response of second order system" , "Time domain specifications" , "Types of systems" , "Steady state error constants" , "Introduction to P, PI and PID modes of feed back control", "(Related Tutorials Using MATLAB/ Simulink – Toolboxes & Functions)"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s422.this, android.R.layout.simple_list_item_1, topic);

        s422.setAdapter(adapter31);

    }
}