package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s333 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s333_layout);

        ListView s333 = (ListView) findViewById(R.id.s333_layout);
        final String[] topic = {"Principle of operation", "Characteristics and signal conditioning- Liquid manometers", "Capacitance diaphragms", "piezoelectric diaphragm", "Venturi flow meters", "Magnetic flow meter", "float switch"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s333.this, android.R.layout.simple_list_item_1, topic);

        s333.setAdapter(adapter31);

    }
}