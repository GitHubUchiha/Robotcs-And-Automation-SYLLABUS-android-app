package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s451 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s451_layout);

        ListView s451 = (ListView) findViewById(R.id.s451_layout);
        final String[] topic = {"Functional Block Diagram" , "Circuit symbol", "Pin Configuration", "circuit schematic of μA 741" , "The ideal OPAMP" , "Open loop gain", "Inverting and Non-inverting amplifiers", "Voltage follower", "Differential amplifier", "CMRR – DC Characteristics:", "input bias and offset currents", "input and output offset voltages", "offset compensation techniques", "thermal drift" , "AC Characteristics:", "Frequency response characteristics" ,"stability", "limitations", "frequency compensation", "slew rate"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s451.this, android.R.layout.simple_list_item_1, topic);

        s451.setAdapter(adapter31);

    }
}