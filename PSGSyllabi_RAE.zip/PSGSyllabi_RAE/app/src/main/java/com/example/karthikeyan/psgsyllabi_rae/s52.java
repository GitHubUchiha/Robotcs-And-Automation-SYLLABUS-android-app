package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s52 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s52_layout);

        ListView s52 = (ListView) findViewById(R.id.s52_layout);
        final String[] topic = {"INTRODUCTION TO FACTORY AUTOMATION","PROGRAMMABLE LOGIC CONTROLLERS","PROGRAMMING OF PLC","HMI SYSTEMS","INSTALLATION","APPLICATIONS OF PLC:","TEXT BOOKS","REFERENCE","List of experiments",""};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s52.this, android.R.layout.simple_list_item_1, topic);

        s52.setAdapter(adapter31);
        s52.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s52.this, s521.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s52.this, s522.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s52.this, s523.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s52.this, s524.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s52.this, s525.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s52.this, s526.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s52.this, s527.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s52.this, s528.class);
                    startActivity(intent);
                }
                if (position == 8) {
                    Intent intent = new Intent(s52.this, s529.class);
                    startActivity(intent);
                }

            }
        });

    }
}