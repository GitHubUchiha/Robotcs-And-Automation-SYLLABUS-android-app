package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s415 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s415_layout);

        ListView s415 = (ListView) findViewById(R.id.s415_layout);
        final String[] topic = {"Estimation of a random variable", "linear estimation of X given Y", "MAP and ML Estimation"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s415.this, android.R.layout.simple_list_item_1, topic);

        s415.setAdapter(adapter31);

    }
}