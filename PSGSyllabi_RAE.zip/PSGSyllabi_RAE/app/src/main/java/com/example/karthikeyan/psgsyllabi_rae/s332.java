package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s332 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s332_layout);

        ListView s332 = (ListView) findViewById(R.id.s332_layout);
        final String[] topic = {"Terminology", "principle of operation", "Characteristics and signal conditioning- Bimetallic thermostats", "Resistance Temperature Detectors", "Thermistors", "Thermocouples", "solid state temperature sensors"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s332.this, android.R.layout.simple_list_item_1, topic);

        s332.setAdapter(adapter31);

    }
}