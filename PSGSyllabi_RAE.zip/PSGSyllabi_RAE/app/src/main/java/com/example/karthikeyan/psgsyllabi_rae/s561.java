package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s561 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s561_layout);

        ListView s561 = (ListView) findViewById(R.id.s561_layout);
        final String[] topic = {"Register transfer language-register", "bus and memory transfers–Arithmetic", "logic and shift micro operations"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s561.this, android.R.layout.simple_list_item_1, topic);

        s561.setAdapter(adapter31);

    }
}