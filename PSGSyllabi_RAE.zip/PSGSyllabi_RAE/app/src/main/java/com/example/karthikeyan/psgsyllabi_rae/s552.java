package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s552 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s552_layout);

        ListView s552 = (ListView) findViewById(R.id.s552_layout);
        final String[] topic = {"Forces on shafts due to gears", "belts and chains", "estimation of shaft size based on strength and critical speed", "Couplings-types and applications", "Design of square keys-use of standards", "rigid couplings", "flexible flange couplings" , "selection"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s552.this, android.R.layout.simple_list_item_1, topic);

        s552.setAdapter(adapter31);

    }
}