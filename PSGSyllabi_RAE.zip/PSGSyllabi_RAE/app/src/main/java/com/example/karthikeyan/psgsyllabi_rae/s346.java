package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s346 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s346_layout);

        ListView s346 = (ListView) findViewById(R.id.s346_layout);
        final String[] topic = {"1. Boylestead.L.R and Nashelsky.L, 'Electronic Devices and Circuit Theory', Pearson Education India, New Delhi, 2002",
                "2. Millman.J, Grabel.A, 'Microelectronics', Tata McGraw-Hill Publishing Company Ltd., New Delhi 1987"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s346.this, android.R.layout.simple_list_item_1, topic);

        s346.setAdapter(adapter31);

    }
}

