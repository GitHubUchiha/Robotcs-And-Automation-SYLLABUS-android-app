package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s33 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s33_layout);

        ListView s33 = (ListView) findViewById(R.id.s33_layout);
        final String[] topic = {"MEASURING SYSTEM","SENSORS AND TRANSDUCERS FOR TEMPERATURE MEASUREMENT","PRESSURE &FLOW MEASUREMENT","DISPLACEMENT & VELOCITY MEASUREMENT","OTHER SENSORS","SIGNAL CONDITIONING AND INTERFACING","List of experiments","TEXT BOOKS","REFERENCES"};

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(s33.this, android.R.layout.simple_list_item_1, topic);

        s33.setAdapter(adapter3);
        s33.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0)
                {
                    Intent intent = new Intent(s33.this,s331.class);
                    startActivity(intent);
                }
                if(position == 1)
                {
                    Intent intent = new Intent(s33.this,s332.class);
                    startActivity(intent);
                }
                if(position == 2)
                {
                    Intent intent = new Intent(s33.this,s333.class);
                    startActivity(intent);
                }
                if(position == 3)
                {
                    Intent intent = new Intent(s33.this,s334.class);
                    startActivity(intent);
                }
                if(position == 4)
                {
                    Intent intent = new Intent(s33.this,s335.class);
                    startActivity(intent);
                }
                if(position == 5)
                {
                    Intent intent = new Intent(s33.this,s336.class);
                    startActivity(intent);
                }
                if(position == 6)
                {
                    Intent intent = new Intent(s33.this,s337.class);
                    startActivity(intent);
                }
                if(position == 7)
                {
                    Intent intent = new Intent(s33.this,s338.class);
                    startActivity(intent);
                }
                if(position == 8)
                {
                    Intent intent = new Intent(s33.this,s339.class);
                    startActivity(intent);
                }

            }
        });

    }
}