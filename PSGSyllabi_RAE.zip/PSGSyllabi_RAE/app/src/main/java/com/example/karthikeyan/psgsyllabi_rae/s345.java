package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s345 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s345_layout);

        ListView s345 = (ListView) findViewById(R.id.s345_layout);
        final String[] topic = {"Oscillators" , "Barkhausen criteria", "RC and LC oscillators using BJT" , "RC phase shift", "Wien bridge oscillators", "Hartley and Colpitt’s oscillators", "Frequency stability of oscillators", "Crystal oscillators", "Non-sinusoidal oscillator"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s345.this, android.R.layout.simple_list_item_1, topic);

        s345.setAdapter(adapter31);

    }
}
