package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s369 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s369_layout);

        ListView s369 = (ListView) findViewById(R.id.s369_layout);
        final String[] topic = {"1. Mallick M. R., “Environment Laws”, Professional Book Publishers, New Delhi, 2012"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s369.this, android.R.layout.simple_list_item_1, topic);

        s369.setAdapter(adapter31);

    }
}