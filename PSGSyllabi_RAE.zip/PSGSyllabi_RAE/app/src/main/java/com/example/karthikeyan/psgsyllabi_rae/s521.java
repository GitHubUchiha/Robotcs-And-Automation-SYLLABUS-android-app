package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s521 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s521_layout);

        ListView s521 = (ListView) findViewById(R.id.s521_layout);
        final String[] topic = {"History and developments in industrial automation", "Vertical integration of industrial automation", "Control elements in industrial automation", "PLC introduction"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s521.this, android.R.layout.simple_list_item_1, topic);

        s521.setAdapter(adapter31);

    }
}