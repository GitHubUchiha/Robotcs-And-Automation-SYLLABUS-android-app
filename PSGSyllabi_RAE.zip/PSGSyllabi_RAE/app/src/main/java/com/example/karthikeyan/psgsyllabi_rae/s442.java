package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s442 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s442_layout);

        ListView s442 = (ListView) findViewById(R.id.s442_layout);
        final String[] topic = {"Function Prototyping" , "Call by Reference" , "Return by reference" , "Inline functions" , "Default", "Const Arguments" , "Function Overloading" , "Friend and Virtual Functions" , "Classes and Objects" , "Member functions" , "Nesting of Member functions" ,"Private member functions" , "Memory allocation for Objects" , "Static data members" , "Static Member Functions" , "Arrays of Objects" ,"Objects as Function Arguments" , "Friend Functions" , "Returning Objects" , "Const Member functions" , "Pointers to Members"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s442.this, android.R.layout.simple_list_item_1, topic);

        s442.setAdapter(adapter31);

    }
}