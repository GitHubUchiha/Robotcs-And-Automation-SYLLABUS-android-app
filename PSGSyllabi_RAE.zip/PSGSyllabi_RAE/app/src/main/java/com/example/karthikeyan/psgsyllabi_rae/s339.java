package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s339 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s339_layout);

        ListView s339 =(ListView)findViewById(R.id.s339_layout);
        final String[] topic = {"1. Patranabis D, “Sensors and Transducers”, Prentice-Hall of India Private Limited, New Delhi, 2003",
        "2. Ernest O Doebelin, “Measurement systems Application and Design”, Tata McGraw-Hill Book Company, 2010"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s339.this, android.R.layout.simple_list_item_1, topic);

        s339.setAdapter(adapter31);

    }
}
