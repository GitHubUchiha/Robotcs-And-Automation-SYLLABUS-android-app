package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s337 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s337_layout);

        ListView s337 = (ListView) findViewById(R.id.s337_layout);
        final String[] topic = {"1. Measuring quantities using instruments",
                "2. Measurement of temperature using Platinum RTD and plotting its characteristics",
                "3. Measurement of temperature using NTC Thermistor and plotting its characteristics",
                "4. Study of strain measurement using strain gauges and cantilever assembly",
                "5. Flow measurement",
                "6. Study of Input Output characteristics of LVDT",
                "7. To determine linear Range of operation and Sensitivity of LVDT",
                "8. Measurement of speed using a proximity switch",
        "9. Velocity and displacement measurement using Encoder",
        "10. Tactile sensors for force and torque measurement"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s337.this, android.R.layout.simple_list_item_1, topic);

        s337.setAdapter(adapter31);

    }
}