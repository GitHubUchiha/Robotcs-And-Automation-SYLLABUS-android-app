package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s535 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s535_layout);

        ListView s535 = (ListView) findViewById(R.id.s535_layout);
        final String[] topic = {"Classification of End effectors", "Tools as end effectors", "Drive system for grippers","Mechanical","adhesive-vacuum-magnetic-grippers", "Hooks&scoops", "Gripper force analysis and gripper design", "Active and passive grippers"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s535.this, android.R.layout.simple_list_item_1, topic);

        s535.setAdapter(adapter31);

    }
}