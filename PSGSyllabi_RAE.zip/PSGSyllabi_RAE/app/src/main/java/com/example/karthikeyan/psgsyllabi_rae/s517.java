package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s517 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s517_layout);

        ListView s517 = (ListView) findViewById(R.id.s517_layout);
        final String[] topic = {"1. Hamdy A Taha, “Operations Research – An Introduction”, Prentice Hall, 2008.",
        "2. Singiresu S Rao, “Engineering optimization theory and Practice”, New Age International, 1996"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s517.this, android.R.layout.simple_list_item_1, topic);

        s517.setAdapter(adapter31);

    }
}