package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s525 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s525_layout);

        ListView s525 = (ListView) findViewById(R.id.s525_layout);
        final String[] topic = {"Installation and maintenance procedures for PLC" , "Troubleshooting of PLC","PLC Networking", "Networking standards & IEEE Standard" , "Protocols" ,"Field bus" , "Process bus and Ethernet"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s525.this, android.R.layout.simple_list_item_1, topic);

        s525.setAdapter(adapter31);

    }
}