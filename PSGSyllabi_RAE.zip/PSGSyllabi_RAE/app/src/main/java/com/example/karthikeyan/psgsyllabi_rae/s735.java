package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s735 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s735_layout);

        ListView s735 = (ListView) findViewById(R.id.s735_layout);
        final String[] topic = {"DCS" , "architecture" , "local control unit", "programming language", "communication facilities" , "operator interface" , "engineering interfaces" };

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s735.this, android.R.layout.simple_list_item_1, topic);

        s735.setAdapter(adapter31);

    }
}