package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s512 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s512_layout);

        ListView s512 = (ListView) findViewById(R.id.s512_layout);
        final String[] topic = {"Gomory cutting plane methods for all integer and mixed integer programming problems" , "Branch and Bound method (Land – Dolg and Dakin algorithms)"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s512.this, android.R.layout.simple_list_item_1, topic);

        s512.setAdapter(adapter31);

    }
}