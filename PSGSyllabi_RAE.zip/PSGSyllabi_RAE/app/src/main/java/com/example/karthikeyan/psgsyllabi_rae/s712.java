package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s712 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s712_layout);

        ListView s712 = (ListView) findViewById(R.id.s712_layout);
        final String[] topic = {"Errors and error measurements", "Model of measurement", "Statistical measurements", "Propagation of errors", "Motion errors principle –translational body", "rotational body", "geometric and kinematic errors", "Other types of errors in machines" , "thermal", "cutting force induced", "environmental", "common geometric errors" , "cosine", "abbe", "dead path errors", "Methodologies of error elimination"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s712.this, android.R.layout.simple_list_item_1, topic);

        s712.setAdapter(adapter31);

    }
}