package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s367 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s367_layout);

        ListView s367 = (ListView) findViewById(R.id.s367_layout);
        final String[] topic = {"Introduction" , "producer responsibility legislation" , "the Waste Electrical and Electronic Equipment (WEEE) directive" , "the RoHS directive" ,"WEEE health and safety implications" , "MATERIALS USED IN MANUFACTURING ELECTRICAL AND ELECTRONIC PRODUCTS:", "Where do RoHS Proscribed Materials Occur" , "Soldering and the Move to Lead-free Assembly" , "Printed Circuit Board Materials" , "Materials Composition of WEEE:", "Mobile Phones" , "Television" , "Washing Machines"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s367.this, android.R.layout.simple_list_item_1, topic);

        s367.setAdapter(adapter31);

    }
}