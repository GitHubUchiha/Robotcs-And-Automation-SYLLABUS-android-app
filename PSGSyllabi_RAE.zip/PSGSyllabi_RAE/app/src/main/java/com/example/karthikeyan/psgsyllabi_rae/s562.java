package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s562 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s562_layout);

        ListView s562 = (ListView) findViewById(R.id.s562_layout);
        final String[] topic = {"Instruction codes" , "Instructions" , "Timing and Control" , "Instruction Cycle" , "Fetch and Decode" , "Execution",  "Typical register and memory sequence instructions" , "Input, Output and Interrupt" , "Design stages"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s562.this, android.R.layout.simple_list_item_1, topic);

        s562.setAdapter(adapter31);

    }
}