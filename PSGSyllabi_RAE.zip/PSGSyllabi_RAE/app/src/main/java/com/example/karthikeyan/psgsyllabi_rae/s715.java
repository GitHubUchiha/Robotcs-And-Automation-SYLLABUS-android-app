package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s715 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s715_layout);

        ListView s715 = (ListView) findViewById(R.id.s715_layout);
        final String[] topic = {"Fundamentals of motion control" , "system modeling and performance assessment" , "linear dynamics", "nonlinear dynamics" , "force ripple", "friction", "hysteresis", "incorporating nonlinear dynamics", "Control design strategies" , "PID feedback", "feed forward control", "ripple", "RBF compensation", "internal model control" , "Case study:", "Design of piezoelectric actuator" , "piezoelectric actuator", "LVDT","adaptive controller"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s715.this, android.R.layout.simple_list_item_1, topic);

        s715.setAdapter(adapter31);

    }
}