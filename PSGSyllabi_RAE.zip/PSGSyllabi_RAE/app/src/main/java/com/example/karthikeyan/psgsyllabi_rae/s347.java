package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s347 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s347_layout);

        ListView s347 = (ListView) findViewById(R.id.s347_layout);
        final String[] topic = {"1. Adel.S.Sedra and Kenneth.C.Smith, 'Microelectronic Circuits', Oxford University Press, New York, 1998",
                "2. Thomas.L.Floyd, 'Electronic Devices', Pearson Education India, New Delhi, 2000",
                "3. David.A.Bell, 'Electronic Devices and Circuits', Prentice Hall of India, New Delhi, 2000"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s347.this, android.R.layout.simple_list_item_1, topic);

        s347.setAdapter(adapter31);

    }
}

