package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s722 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s722_layout);

        ListView s722 = (ListView) findViewById(R.id.s722_layout);
        final String[] topic = {"Introduction","Challenges of Localization", "Map Representation", "Probabilistic Map based Localization", "Monte carlo localization", "Landmark based navigation-Globally unique localization", "Positioning beacon systems", "Route based localization"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s722.this, android.R.layout.simple_list_item_1, topic);

        s722.setAdapter(adapter31);

    }
}