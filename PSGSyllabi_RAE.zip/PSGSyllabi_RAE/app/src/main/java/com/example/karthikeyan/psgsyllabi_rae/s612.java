package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s612 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s612_layout);

        ListView s612 = (ListView) findViewById(R.id.s612_layout);
        final String[] topic = {"Single phase" , "Three phase" , "Half controlled" , "Full controlled rectifiers" , "Dual converters" , "Effect of source and load inductance" , "AC regulators(No derivations)"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s612.this, android.R.layout.simple_list_item_1, topic);

        s612.setAdapter(adapter31);

    }
}