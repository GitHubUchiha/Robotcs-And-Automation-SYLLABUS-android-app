package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s75 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s75_layout);

        ListView s75 = (ListView) findViewById(R.id.s75_layout);
        final String[] topic = {"Students have to do design a product based on the given topic. It includes modeling, simulation, and design of a particular product."};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s75.this, android.R.layout.simple_list_item_1, topic);

        s75.setAdapter(adapter31);

    }
}