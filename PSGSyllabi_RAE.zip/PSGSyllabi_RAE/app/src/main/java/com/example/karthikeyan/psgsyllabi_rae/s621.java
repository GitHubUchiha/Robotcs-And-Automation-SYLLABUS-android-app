package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s621 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s621_layout);

        ListView s621 = (ListView) findViewById(R.id.s621_layout);
        final String[] topic = {"Embedded system", "Functional building block of embedded system", "Characteristics of embedded system applications", "Challenges in embedded system design", "Embedded system design processes"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s621.this, android.R.layout.simple_list_item_1, topic);

        s621.setAdapter(adapter31);

    }
}