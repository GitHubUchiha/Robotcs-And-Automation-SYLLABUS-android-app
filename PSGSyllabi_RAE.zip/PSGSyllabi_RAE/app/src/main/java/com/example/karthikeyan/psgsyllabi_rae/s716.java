package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s716 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s716_layout);

        ListView s716 = (ListView) findViewById(R.id.s716_layout);
        final String[] topic = {"1. Samir Mekid, “Introduction to Precision Machine Design and Error Assessment”, CRC-Press, Taylor and Francis Group, New York, 2009",
        "2. Alexander H Slocum, “Precision Machine Design”, Prentice Hall Publishers, 1992",
        "3. Moore W R, “Foundations of Mechanical Accuracy”, The Moore Special Tool Company, Bridgeport, Connecticut, 1970",
        "4. Nakazawa H, “Principles of Precision Engineering”, Oxford University Press, Oxford, 1994",
        "5. Smith S.T, Chetwynd D.G, “Foundations of Ultra – Precision Mechanism Design”, Gordon and Breach Publishers, Switzerland, 1992"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s716.this, android.R.layout.simple_list_item_1, topic);

        s716.setAdapter(adapter31);

    }
}