package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s454 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s454_layout);

        ListView s454 = (ListView) findViewById(R.id.s454_layout);
        final String[] topic = {"Block diagram of 723 general purpose voltage regulator" , "Circuit configurations", "Current limiting schemes", "Output current boosting", "Fixed and adjustable three terminal regulators", "Switching regulators"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s454.this, android.R.layout.simple_list_item_1, topic);

        s454.setAdapter(adapter31);

    }
}