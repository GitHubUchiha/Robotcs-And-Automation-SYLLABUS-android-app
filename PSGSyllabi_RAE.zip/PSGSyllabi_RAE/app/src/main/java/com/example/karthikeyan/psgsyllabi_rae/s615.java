package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s615 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s615_layout);

        ListView s615 = (ListView) findViewById(R.id.s615_layout);
        final String[] topic = {"Basic characteristics of DC motor" , "Operating modes" , "quadrant operation of chopper" , "Closed loop control of DC drives"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s615.this, android.R.layout.simple_list_item_1, topic);

        s615.setAdapter(adapter31);

    }
}