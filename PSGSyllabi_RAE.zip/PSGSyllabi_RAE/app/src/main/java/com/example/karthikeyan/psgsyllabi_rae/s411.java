package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s411 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s411_layout);

        ListView s411 = (ListView) findViewById(R.id.s411_layout);
        final String[] topic = {"Introduction", "axioms of probability", "conditional probability", "independence" , "Bayes formula"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s411.this, android.R.layout.simple_list_item_1, topic);

        s411.setAdapter(adapter31);

    }
}