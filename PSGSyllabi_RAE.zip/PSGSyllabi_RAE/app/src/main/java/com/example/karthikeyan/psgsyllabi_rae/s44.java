package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s44 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s44_layout);

        ListView s44 = (ListView) findViewById(R.id.s44_layout);
        final String[] topic = {"PRINCIPLES OF OBJECT ORIENTED PROGRAMMING","FUNCTIONS IN C++","CONSTRUCTORS","INHERITANCE","DATA STRUCTURES","ARRAYS","STACKS","QUEUES","LISTS","SORTING","TEXT BOOKS","REFERENCES","LAB"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s44.this, android.R.layout.simple_list_item_1, topic);

        s44.setAdapter(adapter31);
        s44.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s44.this, s441.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s44.this, s442.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s44.this, s443.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s44.this, s444.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s44.this, s445.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s44.this, s446.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s44.this, s447.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s44.this, s448.class);
                    startActivity(intent);
                }
                if (position == 8) {
                    Intent intent = new Intent(s44.this, s449.class);
                    startActivity(intent);
                }
                if (position == 9) {
                    Intent intent = new Intent(s44.this, s4410.class);
                    startActivity(intent);
                }
                if (position == 10) {
                    Intent intent = new Intent(s44.this, s4411.class);
                    startActivity(intent);
                }
                if (position == 11) {
                    Intent intent = new Intent(s44.this, s4412.class);
                    startActivity(intent);
                }

            }
        });
    }
}
