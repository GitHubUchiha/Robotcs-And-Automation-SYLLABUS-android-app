package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s36 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s36_layout);

        ListView s36 = (ListView) findViewById(R.id.s36_layout);
        final String[] topic = {"INTRODUCTION","WATER QUALITY ENGINEERING","AIR QUALITY ENGINEERING","NOISE POLLUTION","GLOBAL ATMOSPHERIC CHANGE","ELECTRONIC WASTE MANAGEMENT","ELECTRICAL AND ELECTRONIC PRODUCTS","TEXT BOOKS","REFERENCE"};

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(s36.this, android.R.layout.simple_list_item_1, topic);

        s36.setAdapter(adapter3);
        s36.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s36.this, s361.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s36.this, s362.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s36.this, s363.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s36.this, s364.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s36.this, s365.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s36.this, s366.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s36.this, s367.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s36.this, s368.class);
                    startActivity(intent);
                }
                if (position == 8) {
                    Intent intent = new Intent(s36.this, s369.class);
                    startActivity(intent);
                }
                if (position == 9) {
                    Intent intent = new Intent(s36.this, s320.class);
                    startActivity(intent);
                }
            }
        });

    }
}