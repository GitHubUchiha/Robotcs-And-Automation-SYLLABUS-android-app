package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s634 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s634_layout);

        ListView s634 = (ListView) findViewById(R.id.s634_layout);
        final String[] topic = {"Transforming sensor reading", "Mapping Sonar Data", "Aligning laser scan measurements" , "Vision and Tracking:", "Following the road", "Iconic image processing", "Multiscale image processing","Video Tracking" ,"Learning landmarks:" ,"Landmark spatiograms", "K-means Clustering", "EM Clustering"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s634.this, android.R.layout.simple_list_item_1, topic);

        s634.setAdapter(adapter31);

    }
}