package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s38 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s38_layout);

        ListView s38 = (ListView) findViewById(R.id.s38_layout);
        final String[] topic = {"1.No-load and Load Characteristics of DC Shunt Generator",
                "2. Load Characteristics of DC Series Motor",
                "3. Load Characteristics of DC Shunt Motor",
                "4. Load Test on 1-phase Transformer",
                "5. Load Test on 3-phase Induction Motor",
                "6. Load Test on 1-phase Induction Motor",
                "7. Load Test on 3-phase Alternator",
                "8. Electrical Braking of DC motor",
                "9. Electrical Braking of 3-phase Induction Motor",
                "10. Speed control of 3-phase induction motor"};

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(s38.this, android.R.layout.simple_list_item_1, topic);

        s38.setAdapter(adapter3);

    }
}

