package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s548 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s548_layout);

        ListView s548 = (ListView) findViewById(R.id.s548_layout);
        final String[] topic = {"Interrupt structure" , "Timer", "Serial ports and Power control :", "Features and Modes" , "Interfacing and application of stepper motor control"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s548.this, android.R.layout.simple_list_item_1, topic);

        s548.setAdapter(adapter31);

    }
}