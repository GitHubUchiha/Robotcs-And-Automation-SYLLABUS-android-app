package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s434 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s434_layout);

        ListView s434 = (ListView) findViewById(R.id.s434_layout);
        final String[] topic = {"Axis drive arrangements", "ball screw", "timing belts and couplings", "Analog and digital drives","AC&DC servomotors", "DC and AC servo drives for axis motors", "servo tuning", "Stepper motors and drives", "spindle motors & drives- DC &AC", "Selection criteria", "drive optimization and protection"};
        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s434.this, android.R.layout.simple_list_item_1, topic);

        s434.setAdapter(adapter31);

    }
}