package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s463 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s463_layout);

        ListView s463 = (ListView) findViewById(R.id.s463_layout);
        final String[] topic = {"Inertia force and D Alembert’s principle", "Gears" , "gear trains (concept and mechanism)", "Piston and cylinder" , "slider crank mechanism", "Four bar mechanism", "Atwood machine", "Cam and follower mechanism", "coils and springs"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s463.this, android.R.layout.simple_list_item_1, topic);

        s463.setAdapter(adapter31);

    }
}