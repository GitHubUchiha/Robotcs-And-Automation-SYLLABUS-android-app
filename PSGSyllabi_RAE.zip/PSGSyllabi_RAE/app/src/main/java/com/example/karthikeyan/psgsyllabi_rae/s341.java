package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s341 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s341_layout);

        ListView s341 = (ListView) findViewById(R.id.s341_layout);
        final String[] topic = {"conduction in semiconductors", "semiconductor materials-n type and p type - V-I characteristics of P-N junction Diode", "Forward and reverse characteristics" , "Diode current equation" , "Effect of temperature"," The ideal Diode" , "Static and dynamic resistances", "Diode Applications:" ,"Clippers", "Clampers", "Half-wave and Full-wave rectifiers"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s341.this, android.R.layout.simple_list_item_1, topic);

        s341.setAdapter(adapter31);

    }
}
