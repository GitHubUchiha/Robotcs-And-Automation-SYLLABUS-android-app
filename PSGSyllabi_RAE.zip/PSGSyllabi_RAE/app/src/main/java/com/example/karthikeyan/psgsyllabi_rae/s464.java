package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s464 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s464_layout);

        ListView s464 = (ListView) findViewById(R.id.s464_layout);
        final String[] topic = {"Balancing of revolving", "reciprocating masses in single plane and several planes-primary and secondary forces and couples"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s464.this, android.R.layout.simple_list_item_1, topic);

        s464.setAdapter(adapter31);

    }
}