package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s412 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s412_layout);

        ListView s412 = (ListView) findViewById(R.id.s412_layout);
        final String[] topic = {"Discrete random variables" , "Probability mass function" ,"cumulative distribution function", "expectations", "variances and moments of discrete random variables", "Bernoulli and Binomial Random Variables", "Poisson Random Variables", "Geometric Random Variables","Continuous random v ariables-probability density functions", "expectations and variances of continuous random variables", "uniform, normal and exponential random variables"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s412.this, android.R.layout.simple_list_item_1, topic);

        s412.setAdapter(adapter31);

    }
}