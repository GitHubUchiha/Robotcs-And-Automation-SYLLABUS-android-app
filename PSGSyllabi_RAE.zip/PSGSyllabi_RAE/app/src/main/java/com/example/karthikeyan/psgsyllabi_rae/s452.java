package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s452 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s452_layout);

        ListView s452 = (ListView) findViewById(R.id.s452_layout);
        final String[] topic = {"Summing amplifier", "Subtractor", "Instrumentation amplifier", "Integrator and Differentiator", "V-I and I-V converters", "Phase changers", "Sinusoidal oscillators", "Active filters: Design of low pass and high pass filters"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s452.this, android.R.layout.simple_list_item_1, topic);

        s452.setAdapter(adapter31);

    }
}