package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s516 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s516_layout);

        ListView s516 = (ListView) findViewById(R.id.s516_layout);
        final String[] topic = {"Principle of optimality" , "backward and forward induction methods","Calculus method of solution" , "Tabular method of solution" , "shortest path network problems", "applications in production"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s516.this, android.R.layout.simple_list_item_1, topic);

        s516.setAdapter(adapter31);

    }
}