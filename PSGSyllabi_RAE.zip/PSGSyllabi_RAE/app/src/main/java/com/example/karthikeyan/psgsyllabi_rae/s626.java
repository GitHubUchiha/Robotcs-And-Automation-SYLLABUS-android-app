package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s626 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s626_layout);

        ListView s626 = (ListView) findViewById(R.id.s626_layout);
        final String[] topic = {"Design Principles ", "Short Interrupt Routines" , "RTOS Tasks" , "Tasks for Priority" , "Tasks for Encapsulation" , "Creating and Destroying tasks" , "Avoidance" , "Tank Monitoring System Design as example" , "Time Scheduling"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s626.this, android.R.layout.simple_list_item_1, topic);

        s626.setAdapter(adapter31);

    }
}