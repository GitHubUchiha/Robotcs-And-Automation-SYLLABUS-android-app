package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s462 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s462_layout);

        ListView s462 = (ListView) findViewById(R.id.s462_layout);
        final String[] topic = {"Lever" , "first", "second and third types", "straight lever", "rocker arm", "bell crank and differential lever", "Pulley" , "simple and with mechanical advantage", "Hydraulic elevator system", "Simple plane frames" , "hoist frame" , "sign frame"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s462.this, android.R.layout.simple_list_item_1, topic);

        s462.setAdapter(adapter31);

    }
}