package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s316 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s316_layout);

        ListView s316 = (ListView) findViewById(R.id.s316_layout);
        final String[] topic = {"polynomial interpolation for uneven intervals" , "Lagrange’s interpolation polynomial", "Newton’s general interpolating formula", "polynomial interpolation for even intervals", "forward differences", "backward differences"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s316.this, android.R.layout.simple_list_item_1, topic);

        s316.setAdapter(adapter31);

    }
}