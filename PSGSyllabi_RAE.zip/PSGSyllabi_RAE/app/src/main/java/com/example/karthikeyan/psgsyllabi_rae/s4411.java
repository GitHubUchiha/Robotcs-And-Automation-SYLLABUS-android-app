package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s4411 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s4411_layout);

        ListView s4411 = (ListView) findViewById(R.id.s4411_layout);
        final String[] topic = {"1. Bjarne Stroustrup, “The C++ Programming Language”, Pearson Education, New Delhi, 2012.",
                "2. Stanley B Lippman, Josee Lajoie and Barbara E Moo, “The C++ Primer”, Pearson Education, New Delhi, 2009.",
                "3. Aaron M Tanenbaum, Moshe J Augenstein and Yedidyah Langsam, 'Data structures using C and C++', Pearson Education, New Delhi, 2009.",
                "4. Sahni Sartaj, 'Data Structures, Algorithms and Applications in C++', Universities Press, Hyderabad, 2005"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s4411.this, android.R.layout.simple_list_item_1, topic);

        s4411.setAdapter(adapter31);

    }
}