package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s731 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s731_layout);

        ListView s731 = (ListView) findViewById(R.id.s731_layout);
        final String[] topic = { "Need", "components of TIA systems", "advantages", "Programmable Automation Controllers (PAC)", "Verical Integration structure"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s731.this, android.R.layout.simple_list_item_1, topic);

        s731.setAdapter(adapter31);

    }
}