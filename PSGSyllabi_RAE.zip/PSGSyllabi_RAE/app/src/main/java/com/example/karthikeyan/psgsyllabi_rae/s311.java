package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s311 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s311_layout);

        ListView s311 = (ListView) findViewById(R.id.s311_layout);
        final String[] topic = {"General vector spaces","real vector spaces","Euclidean n-space","subspaces","linear independence, basis and dimension","row space", "column space and null space", "Eigen values and Eigen vectors", "diagonalization"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s311.this, android.R.layout.simple_list_item_1, topic);

        s311.setAdapter(adapter31);

    }
}
