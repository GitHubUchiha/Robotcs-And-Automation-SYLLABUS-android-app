package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s61 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s61_layout);

        ListView s61 = (ListView) findViewById(R.id.s61_layout);
        final String[] topic = {"REVIEW OF POWER SEMICONDUCTOR DEVICES","CONVERTERS","INVERTERS AND CHOPPERS","INTRODUCTION TO DRIVES","DC DRIVES","AC DRIVES","TEXT BOOKS","REFERENCES"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s61.this, android.R.layout.simple_list_item_1, topic);

        s61.setAdapter(adapter31);
        s61.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s61.this, s611.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s61.this, s612.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s61.this, s613.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s61.this, s614.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s61.this, s615.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s61.this, s616.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s61.this, s617.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s61.this, s618.class);
                    startActivity(intent);
                }


            }
        });


    }
}