package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s449 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s449_layout);

        ListView s449 = (ListView) findViewById(R.id.s449_layout);
        final String[] topic = {"Primitive Operations" , "Singly linked lists", "Doubly linked lists", "Circular lists" , "Applications:", "Addition of Polynomials", "Sparse Matrix representation and Operations" , "Linked Stacks" , "Linked queues"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s449.this, android.R.layout.simple_list_item_1, topic);

        s449.setAdapter(adapter31);

    }
}