package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s71 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s71_layout);

        ListView s71 = (ListView) findViewById(R.id.s71_layout);
        final String[] topic = {"INTRODUCTION TO PRECISION ENGINEERING","MOTION ERRORS","DESIGN STRATEGIES FOR MACHINE TOOLS","PARALLEL KINEMATIC MACHINES (PKM)","PRECISION CONTROL","REFERENCES"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s71.this, android.R.layout.simple_list_item_1, topic);

        s71.setAdapter(adapter31);
        s71.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s71.this, s711.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s71.this, s712.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s71.this, s713.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s71.this, s714.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s71.this, s715.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s71.this, s716.class);
                    startActivity(intent);
                }
            
                  


            }
        });


    }
}