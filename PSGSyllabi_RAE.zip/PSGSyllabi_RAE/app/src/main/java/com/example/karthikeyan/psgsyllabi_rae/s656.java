package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s656 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s656_ayout);

        ListView s656 = (ListView) findViewById(R.id.s656_layout);
        final String[] topic = {"Money" , "Functions" , "Quantity theory of money" , "Banking" , "Commercial Banks" , "Functions" , "Central Bank (RBI)" , "Functions" , "Case Study in Recent Development in Banking"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s656.this, android.R.layout.simple_list_item_1, topic);

        s656.setAdapter(adapter31);

    }
}