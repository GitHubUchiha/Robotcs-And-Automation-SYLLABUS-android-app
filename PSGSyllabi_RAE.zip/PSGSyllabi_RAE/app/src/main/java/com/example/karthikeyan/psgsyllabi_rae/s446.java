package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s446 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s446_layout);

        ListView s446 = (ListView) findViewById(R.id.s446_layout);
        final String[] topic = {"Operations" , "Implementation of one, two, three and multi dimensioned arrays" , "Sparse and dense matrices" , "Applications"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s446.this, android.R.layout.simple_list_item_1, topic);

        s446.setAdapter(adapter31);

    }
}