package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s628 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s628_layout);

        ListView s628 = (ListView) findViewById(R.id.s628_layout);
        final String[] topic = {"1. Wayne Wolf, 'Computers as Components: Principles of Embedded Computer Systems Design', The Morgan Kaufmann Series in Computer Architecture and Design, Elsevier Publications, 2008", "2. Rajkamal, “Embedded Systems – Architecture, Programming and Design”, Tata McGraw-Hill Publishing Company Ltd.,New Delhi, 2010.", "3. Sriram V Iyer, Pankaj Gupta, “Embedded Real-time Systems Programming”, Tata McGraw-Hill Publishing Company Ltd, New Delhi, 2008"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s628.this, android.R.layout.simple_list_item_1, topic);

        s628.setAdapter(adapter31);

    }
}