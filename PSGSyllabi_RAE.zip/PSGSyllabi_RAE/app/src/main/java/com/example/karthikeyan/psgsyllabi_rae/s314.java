package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s314 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s314_layout);

        ListView s314 = (ListView) findViewById(R.id.s314_layout);
        final String[] topic = {"Power method", "Jacobi method"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s314.this, android.R.layout.simple_list_item_1, topic);

        s314.setAdapter(adapter31);

    }
}