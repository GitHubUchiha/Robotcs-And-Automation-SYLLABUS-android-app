package com.example.karthikeyan.psgsyllabi_rae;

        import android.app.Activity;
        import android.os.Bundle;
        import android.widget.ArrayAdapter;
        import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s361 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s361_layout);

        ListView s361 = (ListView) findViewById(R.id.s361_layout);
        final String[] topic = {"What is Environmental Science" , "Introduction to Environmental Engineering" , "Environmental Systems Overview" , "Environment (Protection) Act" , "1986 – Environmental Ethics", "MATERIALS AND ENERGY BALANCES:", "Introduction" , "Unifying Theories" , "Materials Balances" , "Energy Balances" , "Environmental Impact Assessment" , "Environmental Management Standard ISO 14000"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s361.this, android.R.layout.simple_list_item_1, topic);

        s361.setAdapter(adapter31);

    }
}