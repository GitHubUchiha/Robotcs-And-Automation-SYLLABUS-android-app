package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s325 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s325_layout);

        ListView s325 = (ListView) findViewById(R.id.s325_layout);
        final String[] topic = {"Mealy/Moore models – Concept of state", "State diagram, state assignment", "State table, ASM chart", "Design of synchronous sequential circuits – Up-down / Modulus counters", "Serial adder", "Sequence detector", "Introduction to Asynchronous Sequential Circuits"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s325.this, android.R.layout.simple_list_item_1, topic);

        s325.setAdapter(adapter31);

    }
}
