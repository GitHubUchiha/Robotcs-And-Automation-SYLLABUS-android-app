package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s5 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s5_layout);

        ListView s5 = (ListView) findViewById(R.id.s5_layout);
        final String[] sub5 = {"12R501 OPERATIONS RESEARCH","12R502 PROGRAMMABLE LOGIC CONTROLLERS","12R503 BASICS OF ROBOTICS","12R504 MICROPROCESSORS AND MICROCONTROLLERS","12R505 MECHANICAL DESIGN","12R506 COMPUTER ARCHITECTURE","12R510 ENGINEERING DESIGN LABORATORY","12R511 ROBOTICS LABORATORY","12R520 INNOVATION LABORATORY"};

        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(s5.this, android.R.layout.simple_list_item_1, sub5);

        s5.setAdapter(adapter5);

        s5.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0)
                {
                    Intent intent = new Intent(s5.this,s51.class);
                    startActivity(intent);
                }
                if(position == 1)
                {
                    Intent intent = new Intent(s5.this,s52.class);
                    startActivity(intent);
                }
                if(position == 2)
                {
                    Intent intent = new Intent(s5.this,s53.class);
                    startActivity(intent);
                }
                if(position == 3)
                {
                    Intent intent = new Intent(s5.this,s54.class);
                    startActivity(intent);
                }
                if(position == 4)
                {
                    Intent intent = new Intent(s5.this,s55.class);
                    startActivity(intent);
                }
                if(position == 5)
                {
                    Intent intent = new Intent(s5.this,s56.class);
                    startActivity(intent);
                }
                if(position == 6)
                {
                    Intent intent = new Intent(s5.this,s57.class);
                    startActivity(intent);
                }
                if(position == 7)
                {
                    Intent intent = new Intent(s5.this,s58.class);
                    startActivity(intent);
                }
                if(position == 8)
                {
                    Intent intent = new Intent(s5.this,s59.class);
                    startActivity(intent);
                }
            }
        });

    }
}
