package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s524 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s524_layout);

        ListView s524 = (ListView) findViewById(R.id.s524_layout);
        final String[] topic = {"Necessity and Role in Industrial Automation", "Text display" , "operator panels" , "Touch panels" , "Panel PCs" , "Integrated displays", "interfacing PLC to HMI"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s524.this, android.R.layout.simple_list_item_1, topic);

        s524.setAdapter(adapter31);

    }
}