package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s456 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s456_layout);

        ListView s456 = (ListView) findViewById(R.id.s456_layout);
        final String[] topic = {"DAC/ADC performance characteristics" , "Digital to Analog Converters:", "Binary weighted and R-2R Ladder types" , "Analog to digital converters:", "Continuous", "Counter ramp", "Successive approximation"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s456.this, android.R.layout.simple_list_item_1, topic);

        s456.setAdapter(adapter31);

    }
}