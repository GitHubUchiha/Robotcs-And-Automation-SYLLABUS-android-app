package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s555 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s555_layout);

        ListView s555 = (ListView) findViewById(R.id.s555_layout);
        final String[] topic = {"Clutches" , "role of clutches", "positive and gradually engaged clutches", "toothed claw clutches", "design of single plate and multiple plate clutches", "variable speed drives", "types and selection"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s555.this, android.R.layout.simple_list_item_1, topic);

        s555.setAdapter(adapter31);

    }
}