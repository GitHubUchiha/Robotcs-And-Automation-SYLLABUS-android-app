package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s49 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s49_layout);

        ListView s49 = (ListView) findViewById(R.id.s49_layout);
        final String[] topic = {"1 Characteristics and Applications of Op-Amp",
                "2. Waveform Generation using Op-Amp",
                "3. Performance characteristics of Voltage Regulator ICs",
                "4. Study of 555 Timer and 566 VCO",
                "5. Design and Implementation of Active Filters",
                "6. Determination of transfer function of DC servomotor",
                "7. Determination of transfer function of AC servomotor and study of synchros",
                "8. Time domain Response of first order and second order systems using MATLAB",
                "9. Frequency response of first and second order system using MATLAB",
                "10. Characteristics of PID controllers using MATLAB"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s49.this, android.R.layout.simple_list_item_1, topic);

        s49.setAdapter(adapter31);

    }
}
