package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s353 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s353_layout);

        ListView s353 = (ListView) findViewById(R.id.s353_layout);
        final String[] topic = {"Construction" , "types" , "principle of operation of three-phase induction motors" , "equivalent circuit" , "starting and speed control" , "single-phase induction motors (only qualitative analysis)"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s353.this, android.R.layout.simple_list_item_1, topic);

        s353.setAdapter(adapter31);

    }
}