package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s327 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s327_layout);

        ListView s327 = (ListView) findViewById(R.id.s327_layout);
        final String[] topic = {"Characteristics of digital ICs – Voltage and current ratings", "Noise margin", "Propagation delay", "Power dissipation", "TTL logic family – Totem pole", "Open collector and tristate outputs", "Wired output operations", "LS", "ALS and Fast sub families", "MOS transistor switches –nMOS Inverter / Logic gates", "CMOS logic", "Inverter / logic gates", "Multiplexers – High speed CMOS (74HC, 74HCT, 74AHC, 74AHCT logic sub-families) and ECL logic families – Comparison of performance of various logic families"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s327.this, android.R.layout.simple_list_item_1, topic);

        s327.setAdapter(adapter31);

    }
}