package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s646 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s646_layout);

        ListView s646 = (ListView) findViewById(R.id.s646_layout);
        final String[] topic = {"Introduction", "Design of parts for high speed feeding and orienting", "high speed automatic insertion", "Analysis of an assembly", "General rules for product design for automation"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s646.this, android.R.layout.simple_list_item_1, topic);

        s646.setAdapter(adapter31);

    }
}