package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s31 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s31_layout);

        ListView s31 = (ListView) findViewById(R.id.s31_layout);
        final String[] topic = {"VECTOR SPACE","ERRORS","SYSTEM OF LINEAR EQUATIONS","EIGEN VALUES AND EIGENVECTORS","SOLUTONS OF NONLINEAR EQUATIONS","APPROXIMATING FUNCTIONS","DIFFERENTIATION AND INTEGRATION","ORDINARY DIFFERENTIAL EQUATIONS","TEXT BOOKS","REFERENCE BOOKS"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s31.this, android.R.layout.simple_list_item_1, topic);

        s31.setAdapter(adapter31);
        s31.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0)
                {
                    Intent intent = new Intent(s31.this,s311.class);
                    startActivity(intent);
                }
                if(position == 1)
                {
                    Intent intent = new Intent(s31.this,s312.class);
                    startActivity(intent);
                }
                if(position == 2)
                {
                    Intent intent = new Intent(s31.this,s313.class);
                    startActivity(intent);
                }
                if(position == 3)
                {
                    Intent intent = new Intent(s31.this,s314.class);
                    startActivity(intent);
                }
                if(position == 4)
                {
                    Intent intent = new Intent(s31.this,s315.class);
                    startActivity(intent);
                }
                if(position == 5)
                {
                    Intent intent = new Intent(s31.this,s316.class);
                    startActivity(intent);
                }
                if(position == 6)
                {
                    Intent intent = new Intent(s31.this,s317.class);
                    startActivity(intent);
                }
                if(position == 7)
                {
                    Intent intent = new Intent(s31.this,s318.class);
                    startActivity(intent);
                }
                if(position == 8)
                {
                    Intent intent = new Intent(s31.this,s319.class);
                    startActivity(intent);
                }
                if(position == 9)
                {
                    Intent intent = new Intent(s31.this,s320.class);
                    startActivity(intent);
                }
            }
        });

    }
}

//"","","","","","","",""