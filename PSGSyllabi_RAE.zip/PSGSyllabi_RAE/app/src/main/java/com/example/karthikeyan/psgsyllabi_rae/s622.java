package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s622 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s622_layout);

        ListView s622 = (ListView) findViewById(R.id.s622_layout);
        final String[] topic = {"Types of Embedded systems" , "Cordless Bar-Code Scanner" , "Laser Printer" , "underground tank monitor" , "Performance & Design issues" , "Throughput" , "Response" , "Testability" , "Debuggability" , "Reliability" , "Memory space" , "Program Installation" , "Power Consumption" , "Processor Hogs" , "Cost"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s622.this, android.R.layout.simple_list_item_1, topic);

        s622.setAdapter(adapter31);

    }
}