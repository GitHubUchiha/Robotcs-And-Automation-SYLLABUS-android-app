package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s3 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s3_layout);

        final ListView s3 = (ListView) findViewById(R.id.s3_layout);
        final String[] sub3 = {"12R301 LINEAR ALGEBRA AND NUMERICAL ANALYSIS","12R302 DIGITAL ELECTRONICS","12R303 SENSORS AND INSTRUMENTATION","12R304 ELECTRONIC DEVICES AND CIRCUITS","12R305 ELECTRICAL MACHINES AND POWER SYSTEMS","12R306 ENVIRONMENTAL SCIENCE AND ENGINEERING","12R310 ELECTRONIC CIRCUITS AND DIGITAL LABORATORY","12R311 ELECTRICAL MACHINES LABORATORY"};

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(s3.this, android.R.layout.simple_list_item_1, sub3);

        s3.setAdapter(adapter3);

        s3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0)
                {
                    Intent intent = new Intent(s3.this,s31.class);
                    startActivity(intent);
                }
                if(position == 1)
                {
                    Intent intent = new Intent(s3.this,s32.class);
                    startActivity(intent);
                }
                if(position == 2)
                {
                    Intent intent = new Intent(s3.this,s33.class);
                    startActivity(intent);
                }
                if(position == 3)
                {
                    Intent intent = new Intent(s3.this,s34.class);
                    startActivity(intent);
                }
                if(position == 4)
                {
                    Intent intent = new Intent(s3.this,s35.class);
                    startActivity(intent);
                }
                if(position == 5)
                {
                    Intent intent = new Intent(s3.this,s36.class);
                    startActivity(intent);
                }
                if(position == 6)
                {
                    Intent intent = new Intent(s3.this,s37.class);
                    startActivity(intent);
                }
                if(position == 7)
                {
                    Intent intent = new Intent(s3.this,s38.class);
                    startActivity(intent);
                }
            }
        });

    }
    }

