package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s616 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s616_layout);

        ListView s616 = (ListView) findViewById(R.id.s616_layout);
        final String[] topic = {"Induction motor", "Performance characteristics" , "Stator and rotor voltage control", "frequency and voltage control" , "Current Control" , "Introduction to synchronous motor, stepper motor, switched reluctance motor drives" , "Basics of vector control"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s616.this, android.R.layout.simple_list_item_1, topic);

        s616.setAdapter(adapter31);

    }
}