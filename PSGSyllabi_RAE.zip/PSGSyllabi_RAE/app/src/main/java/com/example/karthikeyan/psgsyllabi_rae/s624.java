package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s624 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s624_layout);

        ListView s624 = (ListView) findViewById(R.id.s624_layout);
        final String[] topic = {"Round – Robin – Round – Robin with interrupts" , "A simple Bridge as an Example" , "characteristics" , "Functions" , "Queue" , "Scheduling" , "Architecture" , "Assembly and linking" , "Basic compilation techniques" , "Program optimization" ,"Multiple tasks and multiple processes"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s624.this, android.R.layout.simple_list_item_1, topic);

        s624.setAdapter(adapter31);

    }
}