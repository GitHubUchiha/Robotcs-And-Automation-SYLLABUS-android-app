package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s611 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s611_layout);

        ListView s611 = (ListView) findViewById(R.id.s611_layout);
        final String[] topic = {"Power diodes" , "Power transistors" , "Characteristics of SCR, TRIAC, Power MOSFET, IGBT", "Thyristor protection circuits" , "Thyristor triggering circuits"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s611.this, android.R.layout.simple_list_item_1, topic);

        s611.setAdapter(adapter31);

    }
}