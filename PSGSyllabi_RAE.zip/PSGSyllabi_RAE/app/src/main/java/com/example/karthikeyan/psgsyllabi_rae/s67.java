package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s67 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s67_layout);

        ListView s67 = (ListView) findViewById(R.id.s67_layout);
        final String[] topic = {"1. Co-ordinated motion of multiple pneumatic actuators in a desired sequence using Cascade method",
                "2. Integration of fringe condition modules in multiple actuator pneumatic systems",
                "3. Co-ordinated motion of multiple actuator, electro – pneumatic systems in a desired sequence using hard – wire programmed control systems",
                "4. Co-ordinated motion of multiple actuator, electro – pneumatic systems in a desired sequence using PLC",
                "5. Interfacing of an LVDT with a PC for monitoring the displacement of machine slide and raising an alarm if the displacement exceeds specified limit",
                "6. Inspection using Machine vision System",
                "7. Control of speed, direction and number of revolutions of a stepper motor using PC",
                "8. Development of an obstacle avoidance robot using servo motors, ultrasonic and touch sensors"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s67.this, android.R.layout.simple_list_item_1, topic);

        s67.setAdapter(adapter31);

    }
}

