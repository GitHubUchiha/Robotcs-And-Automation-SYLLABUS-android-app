package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s531 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s531_layout);

        ListView s531 = (ListView) findViewById(R.id.s531_layout);
        final String[] topic = {"Specifications of Robots", "Classifications of robots" , "Work envelope" , "Flexible automation versus Robotic technology" , "Applications of Robots"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s531.this, android.R.layout.simple_list_item_1, topic);

        s531.setAdapter(adapter31);

    }
}