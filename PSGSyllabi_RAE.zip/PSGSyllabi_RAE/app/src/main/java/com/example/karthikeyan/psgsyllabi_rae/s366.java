package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s366 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s366_layout);

        ListView s366 = (ListView) findViewById(R.id.s366_layout);
        final String[] topic = {"The Atmosphere of Earth" , "Global Temperature:", "Orbital Variations and Sunspots", "A Simple Global Temperature Model" , "The Greenhouse Effect", "Global Energy Balance" , "Carbon Credit"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s366.this, android.R.layout.simple_list_item_1, topic);

        s366.setAdapter(adapter31);

    }
}