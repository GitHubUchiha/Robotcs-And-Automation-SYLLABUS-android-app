package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s563 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s563_layout);

        ListView s563 = (ListView) findViewById(R.id.s563_layout);
        final String[] topic = {"General register organization" , "Stack organization" , "Instruction formats" , "Addressing modes" , "Data transfer and manipulation" , "Program control" , "Control memory" , "Address sequencer" , "Data path structure" , "CISC characteristics", "RISC Characteristics", "RISC pipeline"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s563.this, android.R.layout.simple_list_item_1, topic);

        s563.setAdapter(adapter31);

    }
}