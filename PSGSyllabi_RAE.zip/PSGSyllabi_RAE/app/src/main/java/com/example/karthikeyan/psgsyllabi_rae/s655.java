package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s655 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s655_layout);

        ListView s655 = (ListView) findViewById(R.id.s655_layout);
        final String[] topic = {"Causes" , "Type of Goods" , "Rivalrous and Non-rivalrous goods" , "Excludable and Non-excludable goods" , "Solutions" , "Government Intervention"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s655.this, android.R.layout.simple_list_item_1, topic);

        s655.setAdapter(adapter31);

    }
}