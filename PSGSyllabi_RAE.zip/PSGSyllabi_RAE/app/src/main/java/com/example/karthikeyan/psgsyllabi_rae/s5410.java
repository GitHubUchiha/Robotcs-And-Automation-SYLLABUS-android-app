package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s5410 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s5410_layout);

        ListView s5410 = (ListView) findViewById(R.id.s5410_layout);
        final String[] topic = {"1. Kenneth L Short, “Microprocessors and Programmed Logic, Pearson Education/PHI, New Delhi, 2004.", "2. The MCS – 80 / 85 Family User’s Manual, INTEL.'8-bit Embedded Controllers', User’s Manual, Intel Corporation,1990"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s5410.this, android.R.layout.simple_list_item_1, topic);

        s5410.setAdapter(adapter31);

    }
}