package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s566 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s566_layout);

        ListView s566 = (ListView) findViewById(R.id.s566_layout);
        final String[] topic = {"Parallelism in uniprocessor systems" , "Taxonomy of architectures" , "SISD", "SIMD", "MISD", "MIMD modes of Memory access" , "shared memory", "distributed memory", "typical applications"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s566.this, android.R.layout.simple_list_item_1, topic);

        s566.setAdapter(adapter31);

    }
}