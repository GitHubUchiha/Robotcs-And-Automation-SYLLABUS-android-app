package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s57 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s57_layout);

        ListView s57 = (ListView) findViewById(R.id.s57_layout);
        final String[] topic = {"1. Solid modeling of engineering components and assembly",
                "2. Determination of stresses and factor of safety in critical machine components by FEM and experimental validation of the results by strain measurement",
                "3. Dynamic analysis of chassis frame of an automobile",
                "4. Crash analysis of an automobile using FEA software",
                "5. Kinematic and dynamic analysis of mechanisms using mechanism analysis software"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s57.this, android.R.layout.simple_list_item_1, topic);

        s57.setAdapter(adapter31);

    }
}
