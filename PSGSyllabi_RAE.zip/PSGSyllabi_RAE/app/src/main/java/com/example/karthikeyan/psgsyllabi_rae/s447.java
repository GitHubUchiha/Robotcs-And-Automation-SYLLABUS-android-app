package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s447 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s447_layout);

        ListView s447 = (ListView) findViewById(R.id.s447_layout);
        final String[] topic = {"Primitive operations" , "Sequential implementation" , "Applications: Subroutine handling, Recursion"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s447.this, android.R.layout.simple_list_item_1, topic);

        s447.setAdapter(adapter31);

    }
}