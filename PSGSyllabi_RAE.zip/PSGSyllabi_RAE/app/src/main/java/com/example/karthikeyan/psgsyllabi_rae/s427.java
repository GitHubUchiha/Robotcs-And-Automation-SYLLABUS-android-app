package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s427 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s427_layout);

        ListView s427 = (ListView) findViewById(R.id.s427_layout);
        final String[] topic = {"1. Nagrath I J, and Gopal, M, 'Control Systems Engineering'Prentice Hall of India, New Delhi, 2008",
                "2. Richard C Dorf and Robert H Bishop,'Modern Control Systems'Addison-Wesley -2007"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s427.this, android.R.layout.simple_list_item_1, topic);

        s427.setAdapter(adapter31);

    }
}