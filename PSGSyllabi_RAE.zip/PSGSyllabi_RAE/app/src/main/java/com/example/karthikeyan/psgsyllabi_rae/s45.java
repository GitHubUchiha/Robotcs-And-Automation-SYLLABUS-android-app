package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s45 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s45_layout);

        ListView s45 = (ListView) findViewById(R.id.s45_layout);
        final String[] topic = {"OPERATIONAL AMPLIFIER CHARACTERISTICS","LINEAR APPLICATIONS OF OPERATIONAL AMPLIFIERS","NON LINEAR APPLICATIONS OF OPERATIONAL AMPLIFIERS","IC VOLTAGE REGULATORS","SPECIAL FUNCTION ICs","A-D and D-A CONVERTERS","TEXT BOOKS","REFERENCES"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s45.this, android.R.layout.simple_list_item_1, topic);

        s45.setAdapter(adapter31);
        s45.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s45.this, s451.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s45.this, s452.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s45.this, s453.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s45.this, s454.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s45.this, s455.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s45.this, s456.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s45.this, s457.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s45.this, s458.class);
                    startActivity(intent);
                }


            }
        });
    }
}