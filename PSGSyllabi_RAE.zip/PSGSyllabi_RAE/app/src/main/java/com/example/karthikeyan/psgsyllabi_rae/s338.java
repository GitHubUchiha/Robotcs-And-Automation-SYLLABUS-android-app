package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s338 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s338_layout);

        ListView s338 = (ListView) findViewById(R.id.s338_layout);
        final String[] topic = {"1. Peter Elgar ,”Sensors for Measurement and Control”, Addison-Wesley Longman Ltd, 1998",
        "2. A.K.Sawhney “Electrical & Electronic Measurement & Instruments”, Dhanpat Rai & Co., 2010"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s338.this, android.R.layout.simple_list_item_1, topic);

        s338.setAdapter(adapter31);

    }
}
