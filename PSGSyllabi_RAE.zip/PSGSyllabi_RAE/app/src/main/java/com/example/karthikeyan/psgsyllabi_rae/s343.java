package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10,02,2016.
 */
public class s343 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s343_layout);

        ListView s343 = (ListView) findViewById(R.id.s343_layout);
        final String[] topic = {"Types of FET", "Symbols" , "Junction FET:", "Formation of depletion region", "operation & transfer characteristics" , "Comparison between FET and BJT", "Introduction to MOSFET" , "Operation", "Drain and transfer characteristics of Enhancement and depletion type MOSFETs" , "CMOS"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s343.this, android.R.layout.simple_list_item_1, topic);

        s343.setAdapter(adapter31);

    }
}

