package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s533 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s533_layout);

        ListView s533 = (ListView) findViewById(R.id.s533_layout);
        final String[] topic = {"Robot drive mechanisms", "hydraulic" , "electric" , "servomotor", "stepper motor" , "pneumatic drives", "Mechanical transmission method" , "Gear transmission", "Belt drives", "cables", "Roller chains", "Link" , "Rod systems" , "Rotary-to-Rotary motion conversion", "Rotary-to-Linear motion conversion", "Rack and Pinion drives", "Lead screws", "Ball Bearing screws"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s533.this, android.R.layout.simple_list_item_1, topic);

        s533.setAdapter(adapter31);

    }
}