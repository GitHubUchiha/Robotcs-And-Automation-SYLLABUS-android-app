package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s625 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s625_layout);

        ListView s625 = (ListView) findViewById(R.id.s625_layout);
        final String[] topic = {"Tasks and Task states" , "Tasks and Data" , "Shared–data problems" , "Reentrancy" , "Reentrancy Rules" , "Semaphores and Shared-data– RTOS Semaphores" , "Initializing semaphores" , "Reentrancy and Semaphores" , "Multiple semaphores" , "Message Queues", "Mailboxes and Pipes" , "Time functions" , "Events" , "Memory Management" , "Interrupt Routine in RTOS Environment"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s625.this, android.R.layout.simple_list_item_1, topic);

        s625.setAdapter(adapter31);

    }
}