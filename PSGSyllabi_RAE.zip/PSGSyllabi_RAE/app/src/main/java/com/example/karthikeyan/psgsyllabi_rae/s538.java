package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s538 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s538_layout);

        ListView s538 = (ListView) findViewById(R.id.s538_layout);
        final String[] topic = {"1. S. R. Deb and S. Deb, ‘Robotics Technology and Flexible Automation’, Tata McGraw Hill Education Pvt. Ltd, 2010.",
        "2. John J.Craig , “Introduction to Robotics”, Pearson, 2009","3. Mikell P. Groover et. al., 'Industrial Robots - Technology, Programming and Applications', McGraw Hill, New York, 2008"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s538.this, android.R.layout.simple_list_item_1, topic);

        s538.setAdapter(adapter31);

    }
}