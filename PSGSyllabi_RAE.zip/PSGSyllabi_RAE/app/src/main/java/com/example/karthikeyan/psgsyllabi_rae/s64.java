package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s64 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s64_layout);

        ListView s64 = (ListView) findViewById(R.id.s64_layout);
        final String[] topic = {"FUNDAMENTAL CONCEPTS OF INDUSTRIAL AUTOMATION","TRANSFER LINES AND AUTOMATED ASSEMBLY","PNEUMATIC CONTROL","PNEUMATIC CONTROL SYSTEM DESIGN","PROGRAMMABLE AUTOMATION","DESIGN FOR HIGH SPEED AUTOMATIC ASSEMBLY","DESIGN OF MECHATRONIC SYSTEMS","ELEMENTS OF HYDRAULIC SYSTEMS","HYDRAULIC SYSTEM DESIGN","ADVANCED TOPICS IN HYDRAULICS AND PNEUMATICS","TEXT BOOKS","REFERENCES"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s64.this, android.R.layout.simple_list_item_1, topic);

        s64.setAdapter(adapter31);
        s64.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s64.this, s641.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s64.this, s642.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s64.this, s643.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s64.this, s644.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s64.this, s645.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s64.this, s646.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s64.this, s647.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s64.this, s648.class);
                    startActivity(intent);
                }
                if (position == 8) {
                    Intent intent = new Intent(s64.this, s649.class);
                    startActivity(intent);
                }
                if (position == 9) {
                    Intent intent = new Intent(s64.this, s6410.class);
                    startActivity(intent);
                }
                if (position == 10) {
                    Intent intent = new Intent(s64.this, s6411.class);
                    startActivity(intent);
                }
                if (position == 11) {
                    Intent intent = new Intent(s64.this, s6412.class);
                    startActivity(intent);
                }


            }
        });


    }
}
