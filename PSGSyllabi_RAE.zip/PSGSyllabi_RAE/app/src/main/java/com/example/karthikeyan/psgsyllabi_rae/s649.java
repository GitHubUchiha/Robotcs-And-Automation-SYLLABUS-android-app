package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s649 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s649_layout);

        ListView s649 = (ListView) findViewById(R.id.s649_layout);
        final String[] topic = {"Power pack–elements", "design", "Pipes- material", "pipe fittings", "seals and packing", "maintenance of hydraulic systems", "Selection criteria for cylinders", "valves", "pipes", "Heat generation in hydraulic system"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s649.this, android.R.layout.simple_list_item_1, topic);

        s649.setAdapter(adapter31);

    }
}