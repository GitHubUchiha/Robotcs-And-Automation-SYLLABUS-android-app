package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s544 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s544_layout);

        ListView s544 = (ListView) findViewById(R.id.s544_layout);
        final String[] topic = {"Memory mapped I/O scheme" , "I/O mapped I/O scheme" , "Input and Output cycles" , "Programmable peripheral interface (8255)", "Data transfer schemes" , "Interfacing simple keyboards and LED displays"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s544.this, android.R.layout.simple_list_item_1, topic);

        s544.setAdapter(adapter31);

    }
}