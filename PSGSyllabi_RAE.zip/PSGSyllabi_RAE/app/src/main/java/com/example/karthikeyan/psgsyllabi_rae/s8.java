package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s8 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s8_layout);

        ListView s8 = (ListView) findViewById(R.id.s8_layout);
        final String[] sub8 = {"12R820 PROJECT WORK II"};

        ArrayAdapter<String> adapter8 = new ArrayAdapter<String>(s8.this, android.R.layout.simple_list_item_1, sub8);

        s8.setAdapter(adapter8);

    }
}