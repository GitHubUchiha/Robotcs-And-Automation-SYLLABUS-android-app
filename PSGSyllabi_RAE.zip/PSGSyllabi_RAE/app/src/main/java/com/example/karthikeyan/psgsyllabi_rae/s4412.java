package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s4412 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s4412_layout);

        ListView s4412 = (ListView) findViewById(R.id.s4412_layout);
        final String[] topic = {"1. Harvey M Deitel,and Paul J Deitel, 'C++ How to Program', Prentice Hall, New Delhi, 2008.",
                "2. Herbert Schildt, 'C++ - The Complete Reference', Tata McGraw Hill, New Delhi, 2012.",
                "3. Nell Dale, “C++ Plus Data Structures”, Jones & Bartlett, Massachusetts, 2011.",
                "4. Mark Allen Weiss, 'Data Structures and Algorithm Analysis in C', Pearson Education, New Delhi, 2007.",
                "5. Robert L Kruse, Bruce P Leung and Clovin L Tondo, 'Data Structures and Program Design in C', Pearson Education, New Delhi, 2009."};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s4412.this, android.R.layout.simple_list_item_1, topic);

        s4412.setAdapter(adapter31);

    }
}