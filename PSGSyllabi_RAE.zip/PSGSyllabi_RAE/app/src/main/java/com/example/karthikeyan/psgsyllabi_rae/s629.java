package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s629 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s629_layout);

        ListView s629 = (ListView) findViewById(R.id.s629_layout);
        final String[] topic = {"1. David E.Simon, “An Embedded Software Primer”, Pearson Education, 1999.",
        "2. Karen S.Ellison, “Developing Real-time Embedded Software”, John Wiley & Sons, Inc, 1994.",
        "3. Jane W.S.Liu, “Real – Time Systems”, Pearson Education, 2001",
        "4. Bruce P.Douglass, “Real-time UML: Developing Efficient objects for Embedded systems”, Pearson Education, 1999"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s629.this, android.R.layout.simple_list_item_1, topic);

        s629.setAdapter(adapter31);

    }
}