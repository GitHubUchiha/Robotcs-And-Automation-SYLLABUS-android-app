package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s724 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s724_layout);

        ListView s724 = (ListView) findViewById(R.id.s724_layout);
        final String[] topic = {"Ariel robots", "Collision avoidance","Robots for agriculture","mining", "exploration", "underwater", "civilian and military applications", "nuclear applications", "Space applications"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s724.this, android.R.layout.simple_list_item_1, topic);

        s724.setAdapter(adapter31);

    }
}