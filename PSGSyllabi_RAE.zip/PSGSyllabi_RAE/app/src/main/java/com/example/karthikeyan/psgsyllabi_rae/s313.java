package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s313 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s313_layout);

        ListView s313 = (ListView) findViewById(R.id.s313_layout);
        final String[] topic = {"Direct methods", "Gauss elimination method", "Gauss Jordan method", "Crout’s method", "iterative methods", "Gauss-Jacobi method", "Gauss–Seidel method" , "convergence criteria"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s313.this, android.R.layout.simple_list_item_1, topic);

        s313.setAdapter(adapter31);

    }
}