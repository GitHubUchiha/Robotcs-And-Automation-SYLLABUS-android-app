package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s362 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s362_layout);

        ListView s362 = (ListView) findViewById(R.id.s362_layout);
        final String[] topic = {"Energy Resources" , "Mineral Resources" , "Soil Resources" , "Parameters of Soil Sustainability", "Soil Conservation ECOSYSTEMS:", "Human Influences on Ecosystems" , "Energy and Mass Flow" , "Nutrient Cycles" , "Population Dynamics" , "Biodiversity" , "Values and Benefits of Biodiversity" , "Threat to Biodiversity", "Conservation of Biodiversity"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s362.this, android.R.layout.simple_list_item_1, topic);

        s362.setAdapter(adapter31);

    }
}