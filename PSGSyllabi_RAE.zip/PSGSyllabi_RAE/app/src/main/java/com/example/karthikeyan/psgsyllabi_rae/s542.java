package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s542 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s542_layout);

        ListView s542 = (ListView) findViewById(R.id.s542_layout);
        final String[] topic = {"Instruction formats", "Addressing modes" , "Instruction set" , "Need for Assembly language" , "Development of Assembly language programs" , "Machine cycles and Timing diagrams"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s542.this, android.R.layout.simple_list_item_1, topic);

        s542.setAdapter(adapter31);

    }
}