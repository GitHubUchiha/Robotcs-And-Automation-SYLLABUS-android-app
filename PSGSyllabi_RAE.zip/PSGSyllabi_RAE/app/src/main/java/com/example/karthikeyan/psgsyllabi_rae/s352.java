package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s352 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s352_layout);

        ListView s352 = (ListView) findViewById(R.id.s352_layout);
        final String[] topic = {"Constructional Details", "Principle Of Operation", "EMF Equation", "Transformation Ratio" , "Transformer on No Load" , "Parameters Referred To HV/LV Windings", "Equivalent Circuit", "Transformer on Load" , "Regulation" , "Testing Load Test" ,"3- PHASE Transformers connections"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s352.this, android.R.layout.simple_list_item_1, topic);

        s352.setAdapter(adapter31);

    }
}