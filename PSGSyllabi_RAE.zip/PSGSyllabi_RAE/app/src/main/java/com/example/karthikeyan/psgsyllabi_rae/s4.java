package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s4 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s4_layout);

        ListView s4 = (ListView) findViewById(R.id.s4_layout);
        final String[] sub4 = {"12R401 PROBABILITY, STATISTICS, AND RANDOM PROCESSES","12R402 AUTOMATIC CONTROL SYSTEMS","12R403 CNC TECHNOLGY","12R404 C++ AND DATA STRUCTURES","12R405 LINEAR INTEGRATED CIRCUITS","12R406 KINEMATICS AND DYNAMICS OF MACHINERY","12R410 CNC AND METROLOGY LABORATORY","12R411 DYNAMICS LABORATORY","12R412 LIC AND CONTROL SYSTEMS LABORATORY"};

        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(s4.this, android.R.layout.simple_list_item_1, sub4);

        s4.setAdapter(adapter4);
        
        s4.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0)
                {
                    Intent intent = new Intent(s4.this,s41.class);
                    startActivity(intent);
                }
                if(position == 1)
                {
                    Intent intent = new Intent(s4.this,s42.class);
                    startActivity(intent);
                }
                if(position == 2)
                {
                    Intent intent = new Intent(s4.this,s43.class);
                    startActivity(intent);
                }
                if(position == 3)
                {
                    Intent intent = new Intent(s4.this,s44.class);
                    startActivity(intent);
                }
                if(position == 4)
                {
                    Intent intent = new Intent(s4.this,s45.class);
                    startActivity(intent);
                }
                if(position == 5)
                {
                    Intent intent = new Intent(s4.this,s46.class);
                    startActivity(intent);
                }
                if(position == 6)
                {
                    Intent intent = new Intent(s4.this,s47.class);
                    startActivity(intent);
                }
                if(position == 7)
                {
                    Intent intent = new Intent(s4.this,s48.class);
                    startActivity(intent);
                }
                if(position == 8)
                {
                    Intent intent = new Intent(s4.this,s49.class);
                    startActivity(intent);
                }
            }
        });

    }
}