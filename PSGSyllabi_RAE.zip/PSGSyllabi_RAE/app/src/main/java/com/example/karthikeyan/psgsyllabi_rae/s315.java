package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s315 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s315_layout);

        ListView s315 = (ListView) findViewById(R.id.s315_layout);
        final String[] topic = {"False position method", "Newton’s method, convergence criteria", "Bairstow’s method","Graeffe’s root squaring method"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s315.this, android.R.layout.simple_list_item_1, topic);

        s315.setAdapter(adapter31);

    }
}