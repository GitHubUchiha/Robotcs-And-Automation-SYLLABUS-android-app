package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s453 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s453_layout);

        ListView s453 = (ListView) findViewById(R.id.s453_layout);
        final String[] topic = {"Comparator" , "Regenerative comparator", "Zero crossing detector", "Window detector", "Sample and hold circuit", "Rectifiers", "Clipper and Clamper", "Logarithmic and Exponential amplifiers", "Multiplier and Divider", "Square and Triangular waveform generators"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s453.this, android.R.layout.simple_list_item_1, topic);

        s453.setAdapter(adapter31);

    }
}