package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s736 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s736_layout);

        ListView s736 = (ListView) findViewById(R.id.s736_layout);
        final String[] topic = { "Case studies of Machine automation", "Process automation", "Introduction to SCADA Comparison between SCADA and DCS"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s736.this, android.R.layout.simple_list_item_1, topic);

        s736.setAdapter(adapter31);

    }
}