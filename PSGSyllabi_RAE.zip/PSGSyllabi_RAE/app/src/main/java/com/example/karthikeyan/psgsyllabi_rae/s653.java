package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s653 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s653_layout);

        ListView s653 = (ListView) findViewById(R.id.s653_layout);
        final String[] topic = {"Concepts" , "Classifications", "Short run and long run cost curves" , "Revenue ", "Concepts" , "Measurement of Profit.(Case Study)"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s653.this, android.R.layout.simple_list_item_1, topic);

        s653.setAdapter(adapter31);

    }
}