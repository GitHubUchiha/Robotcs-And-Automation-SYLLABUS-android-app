package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s627 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s627_layout);

        ListView s627 = (ListView) findViewById(R.id.s627_layout);
        final String[] topic = {"Host and Target Machines" , "Cross" , "compilers Cross" , "Assemblers" , "Tool chains" , "Link / locators for Embedded systems" , "Getting Embedded software into target system" , "PROM Programmers" , "ROM Emulators - In – Circuit Emulators – Flash Memory - Monitors"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s627.this, android.R.layout.simple_list_item_1, topic);

        s627.setAdapter(adapter31);

    }
}