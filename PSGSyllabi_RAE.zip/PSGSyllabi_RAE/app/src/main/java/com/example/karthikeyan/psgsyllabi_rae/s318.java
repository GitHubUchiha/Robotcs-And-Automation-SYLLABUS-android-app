package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s318 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s318_layout);

        ListView s318 = (ListView) findViewById(R.id.s318_layout);
        final String[] topic = {"Numerical methods for IVP"," single step methods"," Euler method"," Runge-Kutta methods"," modified Euler method"," midpoint method (corrected Euler)"," fourth order Runge-Kutta method"," predictor corrector methods- Milne Simpson method"," Adams Bashforth moulton Method"," solution of second order BVP by finite difference method"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s318.this, android.R.layout.simple_list_item_1, topic);

        s318.setAdapter(adapter31);

    }
}
