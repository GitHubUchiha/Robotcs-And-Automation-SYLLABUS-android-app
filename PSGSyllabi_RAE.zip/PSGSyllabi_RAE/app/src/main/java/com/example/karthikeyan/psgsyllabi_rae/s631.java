package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s631 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s631_layout);

        ListView s631 = (ListView) findViewById(R.id.s631_layout);
        final String[] topic = {"Basic Components" , "Elements of visual perception", "Lenses:", "Pinhole cameras", "Gaussian Optics" , "Cameras" , "Camera-Computer interfaces"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s631.this, android.R.layout.simple_list_item_1, topic);

        s631.setAdapter(adapter31);

    }
}