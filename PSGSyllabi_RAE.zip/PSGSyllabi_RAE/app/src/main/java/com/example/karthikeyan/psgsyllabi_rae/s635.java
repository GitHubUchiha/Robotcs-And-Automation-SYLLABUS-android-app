package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s635 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s635_layout);

        ListView s635 = (ListView) findViewById(R.id.s635_layout);
        final String[] topic = {"Basic introduction to Robotic operating System (ROS)" , "Real and Simulated Robots" , "Introduction to OpenCV, Open NI and PCL", "installing and testing ROS camera Drivers", "ROS to OpenCV" , "The cv_bridge Package"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s635.this, android.R.layout.simple_list_item_1, topic);

        s635.setAdapter(adapter31);

    }
}