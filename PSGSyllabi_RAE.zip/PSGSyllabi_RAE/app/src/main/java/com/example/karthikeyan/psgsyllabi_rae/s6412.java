package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s6412 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s6412_layout);

        ListView s6412 = (ListView) findViewById(R.id.s6412_layout);
        final String[] topic = {"1. Mikell P Groover, 'Industrial Robots – Technology Programmes and Applications' , McGraw Hill , New York, USA. 2000",
                "2. Wemer Deppert and Kurt Stoll, “Pneumatic Application”, Kemprath Reihe, Vovel Verlag , Wurzburg, 1976.",
        "3. Steve F Krar, “Computer Numerical Control Simplified“, Industrial Press, 2001.",
        "4. Joffrey Boothroyd, Peter Dewhurst and Winston A. Knight, “Product Design for manufacture and Assembly”, CRC Press, 2011"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s6412.this, android.R.layout.simple_list_item_1, topic);

        s6412.setAdapter(adapter31);

    }
}