package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s6510 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s6510_layout);

        ListView s6510 = (ListView) findViewById(R.id.s6510_layout);
        final String[] topic = {"1. Paul A Samuelson and William, “Economics”, Tata McGraw Hill, New Delhi, 2010",
        "2. Thingan M.L “Money, Banking, International Trade and Public Finance”, Vrinda Publication, 2009",
        "3. Ahuja H.L, “Macro Economic Theory and Policy”, S.Chand and Co, New Delhi, 2010",
        "4. Francis Cherinullem “International Economics”, McGraw Hill Education, 2008",
        "5. Dutt and Sundaram “Indian Economy”, S.Chand and Co, New Delhi, 2011"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s6510.this, android.R.layout.simple_list_item_1, topic);

        s6510.setAdapter(adapter31);

    }
}