package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s6410 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s6410_layout);

        ListView s6410 = (ListView) findViewById(R.id.s6410_layout);
        final String[] topic = {"Electro pneumatics", "ladder diagram", "Servo and Proportional valves" , "types", "operation", "application", "Hydro-Mechanical servo systems", "PLC-construction", "types", "operation", "programming"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s6410.this, android.R.layout.simple_list_item_1, topic);

        s6410.setAdapter(adapter31);

    }
}