package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s457 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s457_layout);

        ListView s457 = (ListView) findViewById(R.id.s457_layout);
        final String[] topic = {"1. Gayakwad A R,'OP-Amps and Linear Integrated circuits', Pearson Education, New Delhi, 2004", "2. Sedra and Smith, “Microelectronic Circuits”, Oxford University Press, 2004"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s457.this, android.R.layout.simple_list_item_1, topic);

        s457.setAdapter(adapter31);

    }
}