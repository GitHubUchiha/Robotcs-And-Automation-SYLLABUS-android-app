package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s41 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s41_layout);

        ListView s41 = (ListView) findViewById(R.id.s41_layout);
        final String[] topic = {"PROBABILITY","RANDOM VARIABLES","MULTIPLE RANDOM VARIABLES","SUM OF RANDOM VARIABLES","STATISTICAL INFERENCE","STOCHASTIC PROCESSES","RANDOM SIGNAL PROCESSING","TEXT BOOKS","REFERENCES"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s41.this, android.R.layout.simple_list_item_1, topic);

        s41.setAdapter(adapter31);
        s41.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s41.this, s411.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s41.this, s412.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s41.this, s413.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s41.this, s414.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s41.this, s415.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s41.this, s416.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s41.this, s417.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s41.this, s418.class);
                    startActivity(intent);
                }
                if (position == 8) {
                    Intent intent = new Intent(s41.this, s419.class);
                    startActivity(intent);
                }
                if (position == 9) {
                    Intent intent = new Intent(s41.this, s320.class);
                    startActivity(intent);
                }
            }
        });


    }
}
