package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s553 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s553_layout);

        ListView s553 = (ListView) findViewById(R.id.s553_layout);
        final String[] topic = {"V belts for given power and velocity ratio", "selection of micro V-belts", "timing belts", "Selection of roller chain and power speed ratio", "silent chain"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s553.this, android.R.layout.simple_list_item_1, topic);

        s553.setAdapter(adapter31);

    }
}