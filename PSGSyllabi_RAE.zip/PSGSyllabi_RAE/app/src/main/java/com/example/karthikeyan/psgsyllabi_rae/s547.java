package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s547 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s547_layout);

        ListView s547 = (ListView) findViewById(R.id.s547_layout);
        final String[] topic = {"Architecture ", "Memory Organization ", "Addressing modes" , "Instruction set" , "Boolean processing", "Simple programs"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s547.this, android.R.layout.simple_list_item_1, topic);

        s547.setAdapter(adapter31);

    }
}