package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s658 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s658_layout);

        ListView s658 = (ListView) findViewById(R.id.s658_layout);
        final String[] topic = {"Meaning" , "Phases of business cycle" , "Inflation" , "Causes" , "Control measures" , "Deflation" , "National Income" , "Concepts" , "Methods of calculating national income" , "Problems in calculating national income"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s658.this, android.R.layout.simple_list_item_1, topic);

        s658.setAdapter(adapter31);

    }
}