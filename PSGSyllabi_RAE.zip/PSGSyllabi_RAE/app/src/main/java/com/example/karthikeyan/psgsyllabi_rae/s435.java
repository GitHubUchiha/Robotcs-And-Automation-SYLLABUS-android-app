package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s435 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s435_layout);

        ListView s435 = (ListView) findViewById(R.id.s435_layout);
        final String[] topic = {"MCCB", "MCB", "control relays", "contactors", "overload relays", "cables & terminations","Applications of feedback devices in CNC machines", "Absolute and incremental encoders", "resolvers", "linear scales", "Proximity switches", "limit switches" , "Thermal sensors", "pressure and float switches", "Positioning of sensors in CNC"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s435.this, android.R.layout.simple_list_item_1, topic);

        s435.setAdapter(adapter31);

    }
}