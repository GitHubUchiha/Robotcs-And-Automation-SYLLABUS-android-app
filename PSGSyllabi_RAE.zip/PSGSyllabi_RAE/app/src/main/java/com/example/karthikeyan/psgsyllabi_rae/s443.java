package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s443 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s443_layout);

        ListView s443 = (ListView) findViewById(R.id.s443_layout);
        final String[] topic = {"Parameterized Constructors" , "Multiple Constructors in a Class" , "Constructors with Default Arguments" , "Dynamic Initialization of Objects" , "Copy and Dynamic Constructors" , "Destructors overloading" , "Overloading Unary and Binary Operators" , "Overloading Binary Operators using Friend functions"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s443.this, android.R.layout.simple_list_item_1, topic);

        s443.setAdapter(adapter31);

    }
}