package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s445 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s445_layout);

        ListView s445 = (ListView) findViewById(R.id.s445_layout);
        final String[] topic = {"Abstract data Types", "Primitive data structures" , "Analysis of algorithms - Best, worst and average case time complexities" , "Notation"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s445.this, android.R.layout.simple_list_item_1, topic);

        s445.setAdapter(adapter31);

    }
}