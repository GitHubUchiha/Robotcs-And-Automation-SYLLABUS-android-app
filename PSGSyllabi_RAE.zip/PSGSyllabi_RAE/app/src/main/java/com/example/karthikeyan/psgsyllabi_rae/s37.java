package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s37 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s37_layout);

        ListView s37 = (ListView) findViewById(R.id.s37_layout);
        final String[] topic = {"1.Characterisitics of diode and clipper circuits","2.Characterisitics of Zener diode and Zener voltage regulator","3.Characteristics of BJT","4.Characterisitics of JFET","5.Characterisitics of JFET","6.Study of Basic Digital ICs","7.Implementation of Adder and Subtractor circuits","8.Design of Code converters","9.Study of Multiplexer and Demultiplexer","10.Design and Implementation of Counters and registers"};

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(s37.this, android.R.layout.simple_list_item_1, topic);

        s37.setAdapter(adapter3);

    }
}