package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s637 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s637_layout);

        ListView s637 = (ListView) findViewById(R.id.s637_layout);
        final String[] topic = {"1 . Rafael C. Gonzalez and Richard E.woods, “Digital Image Processing”, Addition - Wesley Publishing Company, New Delhi, 2007.", "2. Shimon Ullman, “High-Level Vision: Object recognition and Visual Cognition”, A Bradford Book, USA, 2000.", "3. R.Patrick Goebel, “ ROS by Example: A Do-It-Yourself Guide to Robot Operating System – Volume I”, A Pi Robot Production, 2012."};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s637.this, android.R.layout.simple_list_item_1, topic);

        s637.setAdapter(adapter31);

    }
}