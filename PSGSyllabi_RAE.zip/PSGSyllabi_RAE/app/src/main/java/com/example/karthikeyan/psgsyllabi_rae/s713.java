package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s713 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s713_layout);

        ListView s713 = (ListView) findViewById(R.id.s713_layout);
        final String[] topic = {"Standard sizes", "Precision engineering principles" ,"design, modeling and simulation" , "Design roadmap", "conceptual analysis", "materials selection", "kinematic design of bearing and guide ways", "Structural analysis" , "static and dynamic analysis" , "Micro machines" , "design approach", "design challenges" , "kinematics", "interactive forces", "actuators"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s713.this, android.R.layout.simple_list_item_1, topic);

        s713.setAdapter(adapter31);

    }
}