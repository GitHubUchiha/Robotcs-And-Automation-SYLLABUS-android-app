package com.example.karthikeyan.psgsyllabi_rae;

        import android.app.Activity;
        import android.os.Bundle;
        import android.widget.ArrayAdapter;
        import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s461 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s461_layout);

        ListView s461 = (ListView) findViewById(R.id.s461_layout);
        final String[] topic = {"The wedge", "Screw and screw thread" , "Jack screw", "Belt drives" , "flat and V-type", "Breaks and friction clutche"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s461.this, android.R.layout.simple_list_item_1, topic);

        s461.setAdapter(adapter31);

    }
}