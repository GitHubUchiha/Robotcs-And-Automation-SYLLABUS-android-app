package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s654 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s654_layout);

        ListView s654 = (ListView) findViewById(R.id.s654_layout);
        final String[] topic = {"Perfect Competition" , "Characteristics" , "Price and output determination in short run and long run" , "Monopoly" , "Price Discrimination" , "Monopolistic Competition" , "Product Differentiation" , "Oligopoly and Duopoly"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s654.this, android.R.layout.simple_list_item_1, topic);

        s654.setAdapter(adapter31);

    }
}