package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s368 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s368_layout);

        ListView s368 = (ListView) findViewById(R.id.s368_layout);
        final String[] topic = {"1. Mackenzie L. Davis, and David A. Cornwell, “Introduction to Environmental Engineering”, Tata McGraw Hill, New Delhi, 2010",
        "2. William W. Nazarodd and Lisa Alvarez-Cohen, “Environmental Engineering Science”, Wiley-India, New Delhi, 2010",
        "3. Gilbert M Masters, “Introduction to Environmental Engineering and Science”, Prentice Hall of India, New Delhi, 2004",
        "4. R. E. Hester and R. M. Harrison, “Electronic Waste Management”, Royal Society of Chemistry, London, 2009"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s368.this, android.R.layout.simple_list_item_1, topic);

        s368.setAdapter(adapter31);

    }
}