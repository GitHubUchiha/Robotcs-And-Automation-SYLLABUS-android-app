package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s532 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s532_layout);

        ListView s532 = (ListView) findViewById(R.id.s532_layout);
        final String[] topic = {"Positions", "Orientations and frames", "Mappings:", "Changing descriptions from frame to frame", "Operators:", "Translations", "Rotations and Transformations" , "Transformation Arithmetic" , "D-H Representation" , "Forward and inverse Kinematics Of Six Degree of Freedom Robot Arm" , "Robot Arm dynamics"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s532.this, android.R.layout.simple_list_item_1, topic);

        s532.setAdapter(adapter31);

    }
}