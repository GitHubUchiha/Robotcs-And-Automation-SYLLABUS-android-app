package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s551 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s551_layout);

        ListView s551 = (ListView) findViewById(R.id.s551_layout);
        final String[] topic = {"Review of gear fundamentals", "interference", "gear forces", "determining dimensions of a spur gear pair", "Design of helical gears-parallel axis helical gear", "normal and transverse planes", "helix angles", "equivalent number of teeth", "determining dimension of helical gear pair", "nomenclature of straight and bevel gears"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s551.this, android.R.layout.simple_list_item_1, topic);

        s551.setAdapter(adapter31);

    }
}