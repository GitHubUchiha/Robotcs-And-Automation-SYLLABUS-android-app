package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s737 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s737_layout);

        ListView s737 = (ListView) findViewById(R.id.s737_layout);
        final String[] topic = {"1. John.W.Webb & Ronald A. Reis, “Programmable logic controllers: Principles and Applications”, Prentice Hall India, 2003",
        "2. Michael P. Lukas, “Distributed Control systems”, “Van Nostrand Reinfold Company”1995" };

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s737.this, android.R.layout.simple_list_item_1, topic);

        s737.setAdapter(adapter31);

    }
}