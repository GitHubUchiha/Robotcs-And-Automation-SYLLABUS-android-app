package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s63 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s63_layout);

        ListView s63 = (ListView) findViewById(R.id.s63_layout);
        final String[] topic = {"VISION SYSTEM","VISION ALGORITHMS","OBJECT RECOGNITION","APPLICATIONS","ROBOT VISION","TEXTBOOKS","REFERENCES"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s63.this, android.R.layout.simple_list_item_1, topic);

        s63.setAdapter(adapter31);
        s63.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s63.this, s631.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s63.this, s632.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s63.this, s633.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s63.this, s634.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s63.this, s635.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s63.this, s636.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s63.this, s637.class);
                    startActivity(intent);
                }
              

            }
        });

    }
}
