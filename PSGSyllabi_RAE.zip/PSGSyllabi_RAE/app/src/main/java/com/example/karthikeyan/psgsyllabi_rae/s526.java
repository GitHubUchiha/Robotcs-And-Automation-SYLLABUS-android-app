package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s526 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s526_layout);

        ListView s526 = (ListView) findViewById(R.id.s526_layout);
        final String[] topic = {"Case studies of Machine automation", "Process automation", "Selection parameters for PLC", "Introduction to Programmable Automation Controller"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s526.this, android.R.layout.simple_list_item_1, topic);

        s526.setAdapter(adapter31);

    }
}