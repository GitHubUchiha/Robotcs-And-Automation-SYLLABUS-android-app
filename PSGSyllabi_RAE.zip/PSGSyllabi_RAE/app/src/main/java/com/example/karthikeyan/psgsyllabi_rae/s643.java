package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s643 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s643_layout);

        ListView s643 = (ListView) findViewById(R.id.s643_layout);
        final String[] topic = {"Components", "constructional details", "filter", "lubricator", "regulator", "constructional features", "types of cylinders", "control valves for direction", "pressure and flow", "air motors", "air hydraulic equipments"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s643.this, android.R.layout.simple_list_item_1, topic);

        s643.setAdapter(adapter31);

    }
}