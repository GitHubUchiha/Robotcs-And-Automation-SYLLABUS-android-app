package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s633 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s633_layout);

        ListView s633 = (ListView) findViewById(R.id.s633_layout);
        final String[] topic = {"Object recognition", "Approaches to Object Recognition", "Recognition by combination of views" , "objects with sharp edges", "using two views only", "using a single view, use of dept values"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s633.this, android.R.layout.simple_list_item_1, topic);

        s633.setAdapter(adapter31);

    }
}