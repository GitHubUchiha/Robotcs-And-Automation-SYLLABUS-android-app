package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s364 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s364_layout);

        ListView s364 = (ListView) findViewById(R.id.s364_layout);
        final String[] topic = {"Nature of Air Pollution Problems:", "Criteria Pollutants", "Hazardous Air Pollutants", "Acid Deposition", "Petrochemical Smog", "Indoor Air Quality and Global Change", "Air (Prevention and Control of Pollution) Act", "1981 - Air Pollutant Emissions and Controls:", "Characterising","Emissions", "Pollutant Generation by Combustion and Motor Vehicle Emissions" , "Treatment Technology:", "Particle Control Device"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s364.this, android.R.layout.simple_list_item_1, topic);

        s364.setAdapter(adapter31);

    }
}