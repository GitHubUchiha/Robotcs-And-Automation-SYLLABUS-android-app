package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s564 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s564_layout);

        ListView s564 = (ListView) findViewById(R.id.s564_layout);
        final String[] topic = {"Introduction" , "Addition, Subtraction", "Multiplication and Division algorithms" , "Floating point Arithmetic operations" , "BCD Arithmetic operations"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s564.this, android.R.layout.simple_list_item_1, topic);

        s564.setAdapter(adapter31);

    }
}