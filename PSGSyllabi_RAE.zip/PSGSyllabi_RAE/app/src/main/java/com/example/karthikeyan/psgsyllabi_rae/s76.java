package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s76 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s76_layout);

        ListView s76 = (ListView) findViewById(R.id.s76_layout);
        final String[] topic = {" Identification of a problem",
                " Literature survey of identified problem",
                " Finalization of project specification and requirements",
                " Presentation / Demonstration of sub block(s) of the Project ( Hardware / Software / both )"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s76.this, android.R.layout.simple_list_item_1, topic);

        s76.setAdapter(adapter31);

    }
}
