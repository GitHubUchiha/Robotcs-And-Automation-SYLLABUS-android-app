package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s419 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s419_layout);

        ListView s419 = (ListView) findViewById(R.id.s419_layout);
        final String[] topic = {"1. Sheldon M.Ross, “Stochastic Processes”, John Wiley & Sons, ,2004.",
        "2. Medhi.J. “ Stochastic Processes”, New Age International Publishers , 2002.",
        "3. Saeed Ghahramani, “Fundamentals of Probability with Stochastic Processes”, Prentice Hall, 2005.",
        "4. Trivedi K .S, “ Probability and Statistics with Reliability, Queueing and Computer Science Applications”, Prentice Hall, 2003" };

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s419.this, android.R.layout.simple_list_item_1, topic);

        s419.setAdapter(adapter31);

    }
}