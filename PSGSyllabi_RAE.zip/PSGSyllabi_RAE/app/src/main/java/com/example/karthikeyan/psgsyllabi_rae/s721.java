package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s721 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s721_layout);

        ListView s721 = (ListView) findViewById(R.id.s721_layout);
        final String[] topic = {"History of service robotics" , "Present status and future trends" , "Need for service robots" , "applications", "examples and Specifications of service and field Robots.Non conventionalIndustrial robots"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s721.this, android.R.layout.simple_list_item_1, topic);

        s721.setAdapter(adapter31);

    }
}