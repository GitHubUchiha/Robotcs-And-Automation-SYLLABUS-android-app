package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s424 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s424_layout);

        ListView s424 = (ListView) findViewById(R.id.s424_layout);
        final String[] topic = {"Characteristic equation" , "Routh Hurwitz criterion of stability" , "Absolute and Relative stability", "Nyquist stability" , "Nyquist stability criterion", "Assessment of relative stability" , "Gain and Phase Margin", "(Related Tutorials Using MATLAB/ Simulink – Toolboxes & Functions)"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s424.this, android.R.layout.simple_list_item_1, topic);

        s424.setAdapter(adapter31);

    }
}