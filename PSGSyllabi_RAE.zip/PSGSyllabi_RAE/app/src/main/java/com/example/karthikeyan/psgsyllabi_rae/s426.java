package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s426 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s426_layout);

        ListView s426 = (ListView) findViewById(R.id.s426_layout);
        final String[] topic = {"Limitations of conventional control theory" , "Concepts of state", "state variables and state model" , "state model for linear time invariant systems" , "Introduction to state space representation using physical" , "Phase and canonical variables", "(Related Tutorials Using MATLAB/ Simulink – Toolboxes & Functions)"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s426.this, android.R.layout.simple_list_item_1, topic);

        s426.setAdapter(adapter31);

    }
}