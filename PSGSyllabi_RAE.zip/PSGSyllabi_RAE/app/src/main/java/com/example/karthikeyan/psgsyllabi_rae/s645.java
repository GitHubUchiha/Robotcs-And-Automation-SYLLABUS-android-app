package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s645 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s645_layout);

        ListView s645 = (ListView) findViewById(R.id.s645_layout);
        final String[] topic = {"Special design features of CNC systems and features for lathes and machining centers", "Drive system for CNC machine tools", "Introduction to CIM","condition monitoring of manufacturing systems"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s645.this, android.R.layout.simple_list_item_1, topic);

        s645.setAdapter(adapter31);

    }
}