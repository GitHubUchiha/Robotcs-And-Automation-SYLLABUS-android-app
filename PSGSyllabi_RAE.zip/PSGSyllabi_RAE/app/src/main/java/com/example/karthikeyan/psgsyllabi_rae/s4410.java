package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s4410 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s4410_layout);

        ListView s4410 = (ListView) findViewById(R.id.s4410_layout);
        final String[] topic = {"Insertion sort" , "Selection sort" , "Bubble sort" , "Radix sort", "Algorithms and their time complexities"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s4410.this, android.R.layout.simple_list_item_1, topic);

        s4410.setAdapter(adapter31);

    }
}