package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s623 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s623_layout);

        ListView s623 = (ListView) findViewById(R.id.s623_layout);
        final String[] topic = {"Computer architecture taxonomy", "CPUs – Programming input and output","Supervisor mode", "Exceptions & Traps", "Co - processors", "Memory system mechanisms" , "CPU bus",  "Memory devices" , "I/O devices" , "Component interfacing Interrupt" , "Handler" , "Saving and Restoring the content" , "Disabling Interrupts" , "The Shared–data Problem" , "Shared–Data bug" , "Atomic and Critical sections" , "Interrupt Latency"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s623.this, android.R.layout.simple_list_item_1, topic);

        s623.setAdapter(adapter31);

    }
}