package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s537 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s537_layout);

        ListView s537 = (ListView) findViewById(R.id.s537_layout);
        final String[] topic = {"Material transfer", "Machine loading", "Assembly", "inspection", "processing operations and service robots", "Mobile Robots", "Robot cell"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s537.this, android.R.layout.simple_list_item_1, topic);

        s537.setAdapter(adapter31);

    }
}