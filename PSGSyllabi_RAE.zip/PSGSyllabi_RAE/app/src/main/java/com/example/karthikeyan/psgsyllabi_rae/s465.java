package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s465 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s465_layout);

        ListView s465 = (ListView) findViewById(R.id.s465_layout);
        final String[] topic = {"Basic features of vibratory systems", "degrees of freedom", "single degree of freedom system", "natural vibration", "equation of motion" , "damped free vibration and undamped free vibration"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s465.this, android.R.layout.simple_list_item_1, topic);

        s465.setAdapter(adapter31);

    }
}