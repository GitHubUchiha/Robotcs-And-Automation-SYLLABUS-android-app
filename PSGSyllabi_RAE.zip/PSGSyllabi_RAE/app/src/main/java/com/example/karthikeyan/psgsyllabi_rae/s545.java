package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s545 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s545_layout);

        ListView s545 = (ListView) findViewById(R.id.s545_layout);
        final String[] topic = {"Interrupt feature –Characteristics of Interrupts" , "Types of Interrupts" , "Interrupt structure" , "Methods of servicing interrupts" , "Development of Interrupt service subroutines" , "Multiple interrupt requests and their handling" , "Need for Direct Memory Access" , "Devices for handling DMA" , "Typical DMA Controller features"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s545.this, android.R.layout.simple_list_item_1, topic);

        s545.setAdapter(adapter31);

    }
}