package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s644 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s644_layout);

        ListView s644 = (ListView) findViewById(R.id.s644_layout);
        final String[] topic = {"General approach to control system design", "symbols and drawings", "schematic layout", "travel step diagram", "circuit", "control modes", "program control", "sequence control", "cascade method", "Karnaugh-Veitch mapping"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s644.this, android.R.layout.simple_list_item_1, topic);

        s644.setAdapter(adapter31);

    }
}