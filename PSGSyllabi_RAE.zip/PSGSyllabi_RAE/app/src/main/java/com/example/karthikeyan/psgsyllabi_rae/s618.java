package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s618 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s618_layout);

        ListView s618 = (ListView) findViewById(R.id.s618_layout);
        final String[] topic = {"1. Bimal K Bose, “Modern Power Electronics and AC Drives”, Pearson Education, 2002.",
        "2. Joseph Vithyathil, “Power Electronics”, McGraw Hill, USA, 1995.",
        "3. Mohan and Udeland and Robbins, “Power Electronics”, John Wiley and sons, New York, 2003.",
        "4. Vedam Subramaniam, “Thyristor control of Electrical Drives”, Tata McGraw-Hill, New Delhi, 1998"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s618.this, android.R.layout.simple_list_item_1, topic);

        s618.setAdapter(adapter31);

    }
}