package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s365 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s365_layout);

        ListView s365 = (ListView) findViewById(R.id.s365_layout);
        final String[] topic = {"Introduction" , "Sound Power and Intensity","Relative Scale of Sound Pressure Levels" , "Characterisation of Noise"  , "Effects of Noise on People", "Effects on Performance", "Noise Control:", "Source-Path-Receiver Concept:", "Control of Noise Source by Design", "Noise Control in Transmission Path", "Control of Noise Source by Redress", "Protect the Receiver"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s365.this, android.R.layout.simple_list_item_1, topic);

        s365.setAdapter(adapter31);

    }
}