package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s568 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s568_layout);

        ListView s568 = (ListView) findViewById(R.id.s568_layout);
        final String[] topic = {"1. Carl Hamacher V, Vranesic Z G and Zaky S G, “Computer Organization”, McGraw Hill International Edition,New York, , 2002.",
        "2. Kai Hwang and Briggs F A, “Computer Architecture and Parallel Processing”, McGraw Hill International Edition, New York, 1985"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s568.this, android.R.layout.simple_list_item_1, topic);

        s568.setAdapter(adapter31);

    }
}