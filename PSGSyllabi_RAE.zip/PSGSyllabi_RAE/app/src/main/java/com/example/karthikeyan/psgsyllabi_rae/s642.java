package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s642 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s642_layout);

        ListView s642 = (ListView) findViewById(R.id.s642_layout);
        final String[] topic = {"General terminology and analysis", "analysis of transfer lines without storage", "partial automation", "Automated flow lines with storage buffers", "Automated assembly-design for automated assembly", "types of automated assembly systems", "part feeding devices", "analysis of multi-station assembly machines", "AS/RS", "RFID system", "AGVs", "modular fixturing", "Flow line balancing"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s642.this, android.R.layout.simple_list_item_1, topic);

        s642.setAdapter(adapter31);

    }
}