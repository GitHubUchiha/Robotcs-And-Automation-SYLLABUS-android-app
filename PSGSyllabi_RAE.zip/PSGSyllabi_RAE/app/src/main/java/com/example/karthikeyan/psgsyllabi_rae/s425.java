package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s425 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s425_layout);

        ListView s425 = (ListView) findViewById(R.id.s425_layout);
        final String[] topic = {"Root locus concepts" , "Construction of root loci" , "Root contours", "(Related Tutorials Using MATLAB/ Simulink – Toolboxes & Functions)"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s425.this, android.R.layout.simple_list_item_1, topic);

        s425.setAdapter(adapter31);

    }
}