package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s320 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s320_layout);

        ListView s320 = (ListView) findViewById(R.id.s320_layout);
        final String[] topic = {"1 David C.lay, “ Linear Algebra and its Applications ” Addison –Wesley ,2009",
        "2 Gareth Willams “ Linear Algebra with Applications” Narosa Publishing House , 2009",
        "3 Steven C Chapra and Raymond P Canale, “Numerical Methods for Engineers with Software and Programming Applications”, Tata McGraw Hill, 2007",
        "4. Rizwan Butt “Introduction to Numerical Analysis Using Matlab” Infinity Science Press"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s320.this, android.R.layout.simple_list_item_1, topic);

        s320.setAdapter(adapter31);

    }
}