package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s328 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s328_layout);

        ListView s328 = (ListView) findViewById(R.id.s328_layout);
        final String[] topic = {"1. V Tocci R J, Widmer N S and Moss G L, “Digital Systems: Principles and applications”, Pearson Education (Singapore) Pvt. Ltd, 2007",
        "2. Nelson V P, Nagle H T, Carroll B D, and Irwin J D, “Digital Logic Circuit Analysis and Design”, Prentice Hall International Inc., New Jersey, 1996"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s328.this, android.R.layout.simple_list_item_1, topic);

        s328.setAdapter(adapter31);

    }
}