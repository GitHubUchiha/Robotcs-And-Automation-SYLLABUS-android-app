package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s636 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s636_layout);

        ListView s636 = (ListView) findViewById(R.id.s636_layout);
        final String[] topic = {"1 . Carsten Steger, Markus Ulrich, Christian Wiedemann, “ Machine Vision Algorithms and Applications”, WILEY-VCH, Weinheim,2008.", "2 . Damian m Lyons,“Cluster Computing for Robotics and Computer Vision”, World Scientific, Singapore, 2011"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s636.this, android.R.layout.simple_list_item_1, topic);

        s636.setAdapter(adapter31);

    }
}