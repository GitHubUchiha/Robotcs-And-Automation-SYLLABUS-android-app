package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s614 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s614_layout);

        ListView s614 = (ListView) findViewById(R.id.s614_layout);
        final String[] topic = {"Basic Elements of Drive" , "Load chracteritics" , "Selection of Drive"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s614.this, android.R.layout.simple_list_item_1, topic);

        s614.setAdapter(adapter31);

    }
}