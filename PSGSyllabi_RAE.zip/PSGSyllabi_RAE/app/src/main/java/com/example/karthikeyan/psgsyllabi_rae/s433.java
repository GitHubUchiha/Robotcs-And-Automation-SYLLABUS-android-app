package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s433 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s433_layout);

        ListView s433 = (ListView) findViewById(R.id.s433_layout);
        final String[] topic = {"Functions of CNC", "system hardware", "Contouring control" , "interpolation", "software development process", "Parameters and diagnosis features", "Interfacing with keyboard", "monitor", "field inputs", "outputs", "MPG","Open architecture systems and PC based controllers", "Role of PLC in CNC machines" , "hardware and I/O configuration"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s433.this, android.R.layout.simple_list_item_1, topic);

        s433.setAdapter(adapter31);

    }
}