package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s363 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s363_layout);

        ListView s363 = (ListView) findViewById(R.id.s363_layout);
        final String[] topic = {"The Nature of Water Quality Problems:", "Rivers and Streams", "Lakes and Reservoirs", "Ground Water and Oceans and Estuaries" , "Water (Prevention and Control of Pollution) Act", "1974 – Engineered Water Quality Systems" , "Physical Treatment Method:", "Sedimentation" , "Chemical and Physicochemical Treatment Method:", "Disinfection" , "Biological Waster Water Treatment: Activated Sludge}"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s363.this, android.R.layout.simple_list_item_1, topic);

        s363.setAdapter(adapter31);

    }
}