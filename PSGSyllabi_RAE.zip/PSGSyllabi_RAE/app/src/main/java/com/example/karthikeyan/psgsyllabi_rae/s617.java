package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s617 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s617_layout);

        ListView s617 = (ListView) findViewById(R.id.s617_layout);
        final String[] topic = {"1. Rashid M H, “Power Electronics – Circuits, Devices and Applications”, PHI, New Delhi, 2004.",
        "2. Dubey G K, “Power semiconductors and Drives”, Prentice Hall, 1989"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s617.this, android.R.layout.simple_list_item_1, topic);

        s617.setAdapter(adapter31);

    }
}