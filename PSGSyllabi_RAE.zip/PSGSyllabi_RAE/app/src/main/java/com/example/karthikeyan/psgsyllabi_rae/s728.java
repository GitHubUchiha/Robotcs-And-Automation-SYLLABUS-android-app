package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s728 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s728_layout);

        ListView s728 = (ListView) findViewById(R.id.s728_layout);
        final String[] topic = {"1. Richard D Klafter, Thomas A Chmielewski, Michael Negin, 'Robotics Engineering – An Integrated Approach', Eastern Economy Edition, Prentice Hall of India P Ltd., 2006.",
                "2. Kelly, Alonzo; Iagnemma, Karl; Howard, Andrew, 'Field and Service Robotics', Springer, 2011"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s728.this, android.R.layout.simple_list_item_1, topic);

        s728.setAdapter(adapter31);

    }
}