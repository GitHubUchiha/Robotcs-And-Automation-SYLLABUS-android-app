package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s414 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s414_layout);

        ListView s414 = (ListView) findViewById(R.id.s414_layout);
        final String[] topic = {"Expectations of Sums" , "pdf of the Sum of two random variables", "moment generating function" ,
                "sums of independent Gaussian random variables" , "central limit theorem", "laws of large numbers"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s414.this, android.R.layout.simple_list_item_1, topic);

        s414.setAdapter(adapter31);

    }
}