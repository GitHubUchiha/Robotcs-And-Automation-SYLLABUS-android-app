package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s66 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s66_layout);

        ListView s66 = (ListView) findViewById(R.id.s66_layout);
        final String[] topic = {"1. Characteristics of Power semiconductor devices",
                "2. Single Phase and Three Phase Diode Bridge Rectifier with R and RL Load",
                "3. Single Phase Half and Fully Controlled Thyristor converter with R and RL Load",
                "4. DC Chopper with R and RL Load",
                "5. Single Phase AC Voltage Controller with R and RL Load",
                "6. Three Phase PWM Inverter",
                "7. Three Phase AC Voltage Controller with R and RL Load",
                "8. Three Phase Fully Controlled Thyristor converter",
                "9. Performance study of V/f Drive",
                "10. Performance study of DC drive"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s66.this, android.R.layout.simple_list_item_1, topic);

        s66.setAdapter(adapter31);

    }
}
