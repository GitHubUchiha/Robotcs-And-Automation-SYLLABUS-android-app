package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s448 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s448_layout);

        ListView s448 = (ListView) findViewById(R.id.s448_layout);
        final String[] topic = {"Primitive operations" , "Sequential implementation" , "Dequeues" , "Applications: Image component labeling, Machine shop simulation"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s448.this, android.R.layout.simple_list_item_1, topic);

        s448.setAdapter(adapter31);

    }
}