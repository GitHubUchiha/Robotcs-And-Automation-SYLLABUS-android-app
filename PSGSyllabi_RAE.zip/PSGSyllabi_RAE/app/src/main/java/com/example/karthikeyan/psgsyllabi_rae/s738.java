package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s738 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s738_layout);

        ListView s738 = (ListView) findViewById(R.id.s738_layout);
        final String[] topic = {"1. WinCC software manual, Siemens, 2003",
                "2. RS VIEW 32 Software Manual, Allen Bradly, 2005",
                "3. CIMPLICITY SCADA Packages Manual, Fanuc India Ltd, 2004" };

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s738.this, android.R.layout.simple_list_item_1, topic);

        s738.setAdapter(adapter31);

    }
}