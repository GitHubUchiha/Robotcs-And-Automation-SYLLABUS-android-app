package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s7 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s7_layout);

        ListView s7 = (ListView) findViewById(R.id.s7_layout);
        final String[] sub7 = {"12R701 PRECISION EQUIPMENT DESIGN","12R702 FIELD AND SERVICE ROBOTICS","12R703 TOTALLY INTEGRATED AUTOMATION","12R710 TOTALLY INTEGRATED AUTOMATION LABORATORY","12R711 PRODUCT DESIGN LABORATORY","12R720 PROJECT WORK I"};

        ArrayAdapter<String> adapter7 = new ArrayAdapter<String>(s7.this, android.R.layout.simple_list_item_1, sub7);

        s7.setAdapter(adapter7);
        s7.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0)
                {
                    Intent intent = new Intent(s7.this,s71.class);
                    startActivity(intent);
                }
                if(position == 1)
                {
                    Intent intent = new Intent(s7.this,s72.class);
                    startActivity(intent);
                }
                if(position == 2)
                {
                    Intent intent = new Intent(s7.this,s73.class);
                    startActivity(intent);
                }
                if(position == 3)
                {
                    Intent intent = new Intent(s7.this,s74.class);
                    startActivity(intent);
                }
                if(position == 4)
                {
                    Intent intent = new Intent(s7.this,s75.class);
                    startActivity(intent);
                }
                if(position == 5)
                {
                    Intent intent = new Intent(s7.this,s76.class);
                    startActivity(intent);
                }
            }
        });

    }
}