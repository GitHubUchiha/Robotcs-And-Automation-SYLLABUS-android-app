package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s726 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s726_layout);

        ListView s726 = (ListView) findViewById(R.id.s726_layout);
        final String[] topic = {"Material transfer", "Machine loading", "Assembly", "nspection", "processing operations and service robots", "Mobile Robots", "Robot cell"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s726.this, android.R.layout.simple_list_item_1, topic);

        s726.setAdapter(adapter31);

    }
}