package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s714 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s714_layout);

        ListView s714 = (ListView) findViewById(R.id.s714_layout);
        final String[] topic = {"Serial and parallel systems", "Precision design of PKM" , "need of PKM" ,"low cost", "degrees of freedom", "workspace volume", "high stiffness and agility", "repeatability in movement", "low inertia", "Configurations and characteristic issues" , "degrees of calculation", "Design principles" , "Kinematic modeling"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s714.this, android.R.layout.simple_list_item_1, topic);

        s714.setAdapter(adapter31);

    }
}