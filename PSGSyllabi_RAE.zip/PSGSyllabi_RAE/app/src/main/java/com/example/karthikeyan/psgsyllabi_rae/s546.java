package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s546 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s546_layout);

        ListView s546 = (ListView) findViewById(R.id.s546_layout);
        final String[] topic = {"Multiplexed seven segment LED Display systems" , "Stepper motor control" , "Interfacing ADC0801 A/D Converter– DAC 0800 D/A Converter – Square Waveform generation"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s546.this, android.R.layout.simple_list_item_1, topic);

        s546.setAdapter(adapter31);

    }
}