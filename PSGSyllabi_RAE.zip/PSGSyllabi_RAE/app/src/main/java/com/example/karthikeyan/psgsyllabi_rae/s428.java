package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s428 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s428_layout);

        ListView s428 = (ListView) findViewById(R.id.s428_layout);
        final String[] topic = {"1. Ogata K, 'Modern Control Engineering', Pearson Education, New Delhi, 2006",
                "2. Kuo B C, ,Automatic Control Systems', Prentice-Hall of India Pvt. Ltd, New Delhi,2004",
                "3. Norman C. Nise S, “Control system Engineering’, John Wiley & Sons, Singapore,2004"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s428.this, android.R.layout.simple_list_item_1, topic);

        s428.setAdapter(adapter31);

    }
}