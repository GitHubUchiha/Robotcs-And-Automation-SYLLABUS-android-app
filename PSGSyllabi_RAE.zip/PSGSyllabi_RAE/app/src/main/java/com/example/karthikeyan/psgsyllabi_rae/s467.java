package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s467 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s467_layout);

        ListView s467 = (ListView) findViewById(R.id.s467_layout);
        final String[] topic = {"1. R.C Hibbeler and Ashok Gupta, “Engineering Mechanics: Statics and Dynamics”, Prentice Hall, New Delhi, 2009",
        "2. Bevan T, “Theory of Machines”, Third Edition, CBS Publishers and Distributors, New Delhi, 2002",
        "3. Ghosh and Mallick A K, “Theory of Machines and Mechanisms”, Affiliated East West Private Limited New Delhi, 1988",
        "4. Rattan S S, “Theory of Machines”, Tata Mc Graw Hill , New Delhi, 2005.",
        "5. Rao SS, “Mechanical Vibrations”, Addision Wesley Longman, New Delhi, 1995"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s467.this, android.R.layout.simple_list_item_1, topic);

        s467.setAdapter(adapter31);

    }
}