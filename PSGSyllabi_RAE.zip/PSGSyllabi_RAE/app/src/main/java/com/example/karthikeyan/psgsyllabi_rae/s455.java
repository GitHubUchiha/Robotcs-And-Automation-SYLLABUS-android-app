package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s455 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s455_layout);

        ListView s455 = (ListView) findViewById(R.id.s455_layout);
        final String[] topic = {"555 Timer Functional block diagram and description" , "Monostable and Astable operation", "Applications", "566 Voltage Controlled Oscillator", "Analog Multiplier", "Comparator ICs" ,"PLL Functional Block diagram" , "Principle of operation", "Building blocks of PLL", "Characteristics", "Applications:", "Frequency synthesis", "DC Motor speed control"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s455.this, android.R.layout.simple_list_item_1, topic);

        s455.setAdapter(adapter31);

    }
}