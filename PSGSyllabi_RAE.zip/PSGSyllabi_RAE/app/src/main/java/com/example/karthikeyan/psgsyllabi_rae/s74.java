package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s74 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s74_layout);

        ListView s74 = (ListView) findViewById(R.id.s74_layout);
        final String[] topic = {"1. Study of PAC",
                "2. Programming a PAC for a given task",
                "3. Configuring a text display with PLC",
                "4. Programming and configuring a graphical display with PLC",
                "5. Study of SCADA",
                "6. Development of screens for SCADA",
                "7. Interfacing a SCADA with PLC",
                "8. Study of DCS",
                "9. Programming a DCS",
                "10. Controlling a variable speed drive through PLC/SCADA"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s74.this, android.R.layout.simple_list_item_1, topic);

        s74.setAdapter(adapter31);

    }
}
