package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s725 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s725_layout);

        ListView s725 = (ListView) findViewById(R.id.s725_layout);
        final String[] topic = {"Wheeled and legged", "Legged locomotion and balance", "Arm movement", "Gaze and auditory orientation control", "Facial expression", "Hands and manipulation", "Sound and speech generation", "Motion capture/Learning from demonstration", "Human activity recognition using vision", "touch", "sound", "Vision", "Tactile Sensing", "Models of emotion and motivation", "Performance", "Interaction", "Safety and robustness","Applications", "Case studies"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s725.this, android.R.layout.simple_list_item_1, topic);

        s725.setAdapter(adapter31);

    }
}