package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s354 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s354_layout);

        ListView s354 = (ListView) findViewById(R.id.s354_layout);
        final String[] topic = {"Construction of Synchronous machines-types" ,"induced emf" , "brushless alternators", "reluctance motor" , "stepper motor servo motor"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s354.this, android.R.layout.simple_list_item_1, topic);

        s354.setAdapter(adapter31);

    }
}