package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s659 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s659_layout);

        ListView s659 = (ListView) findViewById(R.id.s659_layout);
        final String[] topic = {"1. Dewett. K.K, “Modern Economic Theory”, S. Chand and Company Ltd, New Delhi, 2010",
        "2. Lipsey and Chrystal, “Economics”, Oxford University Press, 2010"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s659.this, android.R.layout.simple_list_item_1, topic);

        s659.setAdapter(adapter31);

    }
}