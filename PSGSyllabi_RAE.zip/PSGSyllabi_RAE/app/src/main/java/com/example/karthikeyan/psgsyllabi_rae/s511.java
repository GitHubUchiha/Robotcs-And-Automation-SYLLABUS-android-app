package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s511 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s511_layout);

        ListView s511 = (ListView) findViewById(R.id.s511_layout);
        final String[] topic = {"Graphical method for two dimensional problems" , "central problems of linear programming", "definitions", "simplex", "algorithm", "phase I and Phase II of simplex method","Simplex Multipliers" , "dual and primal", "dual simplex method" , "transportation problem and its solution" ,"Assignment problem and its solution by Hungarian method" ,"Karmakar’s method" , "statement", "conversion of the linear Programming problem into the required form", "algorithm"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s511.this, android.R.layout.simple_list_item_1, topic);

        s511.setAdapter(adapter31);

    }
}