package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s417 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s417_layout);

        ListView s417 = (ListView) findViewById(R.id.s417_layout);
        final String[] topic = {"Linear filtering of a random process", "power spectral density", "cross correlations", "Gaussian processes"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s417.this, android.R.layout.simple_list_item_1, topic);

        s417.setAdapter(adapter31);

    }
}