package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 10-02-2016.
 */
public class s317 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s317_layout);

        ListView s317 = (ListView) findViewById(R.id.s317_layout);
        final String[] topic = {"Numerical differentiation using forward and backward difference formulas", "numerical integration", "closed Newton-Cotes formulas", "trapezoidal and composite trapezoidal rule", "simpson’s and composite simpson’s rule", "gaussian quadratures"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s317.this, android.R.layout.simple_list_item_1, topic);

        s317.setAdapter(adapter31);

    }
}