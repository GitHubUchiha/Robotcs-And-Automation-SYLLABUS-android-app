package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s723 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s723_layout);

        ListView s723 = (ListView) findViewById(R.id.s723_layout);
        final String[] topic = {"Introduction","Path planning overview", "Road map path planning", "Cell decomposition path planning","Potential field path planning","Obstacle avoidance" , "Case studies: tiered robot architectures"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s723.this, android.R.layout.simple_list_item_1, topic);

        s723.setAdapter(adapter31);

    }
}