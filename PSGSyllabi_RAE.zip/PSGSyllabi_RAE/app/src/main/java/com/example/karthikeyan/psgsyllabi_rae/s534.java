package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s534 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s534_layout);

        ListView s534 = (ListView) findViewById(R.id.s534_layout);
        final String[] topic = {"Construction of Manipulators", "Manipulator Dynamic and Force Control", "Electronic and Pneumatic manipulators"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s534.this, android.R.layout.simple_list_item_1, topic);

        s534.setAdapter(adapter31);

    }
}