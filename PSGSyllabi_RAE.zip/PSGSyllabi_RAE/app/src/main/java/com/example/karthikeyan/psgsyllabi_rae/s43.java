package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s43 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s43_layout);

        ListView s43 = (ListView) findViewById(R.id.s43_layout);
        final String[] topic = {"INTRODUCTION","TYPES OF CNC MACHINES","CONTROL UNITS","DRIVE UNITS","CONTROL AND FEEDBACK DEVICES","NC PART PROGRAMMING PROCESS","ECONOMICS AND MAINTENANCE","TEXT BOOKS","REFERENCES"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s43.this, android.R.layout.simple_list_item_1, topic);

        s43.setAdapter(adapter31);
        s43.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s43.this, s431.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s43.this, s432.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s43.this, s433.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s43.this, s434.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s43.this, s435.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s43.this, s436.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s43.this, s437.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s43.this, s438.class);
                    startActivity(intent);
                }
                if (position == 8) {
                    Intent intent = new Intent(s43.this, s439.class);
                    startActivity(intent);
                }
            }
        });
    }
}
