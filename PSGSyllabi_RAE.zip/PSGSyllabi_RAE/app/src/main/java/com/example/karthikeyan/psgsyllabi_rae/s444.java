package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s444 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s444_layout);

        ListView s444 = (ListView) findViewById(R.id.s444_layout);
        final String[] topic = {"Defining Derived Classes" , "Single Inheritance" , "Making a Private Member Inheritable" , "Multiple Inheritance" , "Hierarchical Inheritance" , "Hybrid Inheritance" , "Virtual Base Classes" , "Abstract Classes" , "Constructors in Derived Classes" , "Member Classes" , "Nesting of Classes"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s444.this, android.R.layout.simple_list_item_1, topic);

        s444.setAdapter(adapter31);

    }
}