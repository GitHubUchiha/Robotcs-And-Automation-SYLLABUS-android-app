package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s416 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s416_layout);

        ListView s416 = (ListView) findViewById(R.id.s416_layout);
        final String[] topic = {"Definition", "types of Stochastic Processes-" , "Poisson Processes" , "The Brownian Motion Process" , "expected value and correlation" , "stationary processes", "wide sense stationary processes"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s416.this, android.R.layout.simple_list_item_1, topic);

        s416.setAdapter(adapter31);

    }
}