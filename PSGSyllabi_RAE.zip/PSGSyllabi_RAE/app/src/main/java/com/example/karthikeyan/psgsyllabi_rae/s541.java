package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s541 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s541_layout);

        ListView s541 = (ListView) findViewById(R.id.s541_layout);
        final String[] topic = {"Functional Block Diagram" , "Registers", "ALU", "Bus systems" , "Timing and control signals"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s541.this, android.R.layout.simple_list_item_1, topic);

        s541.setAdapter(adapter31);

    }
}