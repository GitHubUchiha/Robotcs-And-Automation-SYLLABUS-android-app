package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s6411 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s6411_layout);

        ListView s6411 = (ListView) findViewById(R.id.s6411_layout);
        final String[] topic = {"1. Mikell P Groover, “Automation Production Systems and Computer- Integrated Manufacturing” Pearson Education, New Delhi,2001",
        "2. Wemer Depper and Kurt Stoll, “Pneumatic Application”, Kemprath Reihe, Vogel Buch Verlag Wurzbutg, 1987",
        "3. Bolton W, “Mechatronics“, Pearson Education, 1999"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s6411.this, android.R.layout.simple_list_item_1, topic);

        s6411.setAdapter(adapter31);

    }
}