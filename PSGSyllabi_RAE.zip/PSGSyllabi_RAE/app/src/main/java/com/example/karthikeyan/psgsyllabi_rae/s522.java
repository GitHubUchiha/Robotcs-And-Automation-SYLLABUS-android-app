package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s522 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s522_layout);

        ListView s522 = (ListView) findViewById(R.id.s522_layout);
        final String[] topic = {"Basics of PLC, Advantages", "Capabilities of PLC", "Architecture of PLC", "Scan cycle", "Types of PLC", "Types of I/O modules", "Configuring a PLC", "PLC wiring"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s522.this, android.R.layout.simple_list_item_1, topic);

        s522.setAdapter(adapter31);

    }
}