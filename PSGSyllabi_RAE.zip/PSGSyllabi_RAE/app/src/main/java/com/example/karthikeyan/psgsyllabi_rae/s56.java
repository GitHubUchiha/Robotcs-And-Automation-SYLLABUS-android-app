package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s56 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s56_layout);

        ListView s56 = (ListView) findViewById(R.id.s56_layout);
        final String[] topic = {"INTRODUCTION","BASIC COMPUTER ORGANISATION","CENTRAL PROCESSOR ORGANISATION","ARITHMETIC PROCESSING","MEMORY AND INPUT/OUTPUT ORGANISATION","INTRODUCTION TO PARALLEL PROCESSING","TEXT BOOKS","REFERENCES"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s56.this, android.R.layout.simple_list_item_1, topic);

        s56.setAdapter(adapter31);
        s56.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent intent = new Intent(s56.this, s561.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(s56.this, s562.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(s56.this, s563.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(s56.this, s564.class);
                    startActivity(intent);
                }
                if (position == 4) {
                    Intent intent = new Intent(s56.this, s565.class);
                    startActivity(intent);
                }
                if (position == 5) {
                    Intent intent = new Intent(s56.this, s566.class);
                    startActivity(intent);
                }
                if (position == 6) {
                    Intent intent = new Intent(s56.this, s567.class);
                    startActivity(intent);
                }
                if (position == 7) {
                    Intent intent = new Intent(s56.this, s568.class);
                    startActivity(intent);
                }

            }
        });

    }
}
