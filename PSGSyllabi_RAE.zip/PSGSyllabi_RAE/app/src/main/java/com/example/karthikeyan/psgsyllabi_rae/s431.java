package com.example.karthikeyan.psgsyllabi_rae;

        import android.app.Activity;
        import android.os.Bundle;
        import android.widget.ArrayAdapter;
        import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s431 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s431_layout);

        ListView s431 = (ListView) findViewById(R.id.s431_layout);
        final String[] topic = {"History" , "Advantages and disadvantages of CNC", "block diagram of CNC" , "Principle of operation", "Features available in CNC systems" ,"DNC", "Networking of CNC machines" , "Ethernet", "Electrical cabinet and control panel wiring", "Electrical standards"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s431.this, android.R.layout.simple_list_item_1, topic);

        s431.setAdapter(adapter31);

    }
}