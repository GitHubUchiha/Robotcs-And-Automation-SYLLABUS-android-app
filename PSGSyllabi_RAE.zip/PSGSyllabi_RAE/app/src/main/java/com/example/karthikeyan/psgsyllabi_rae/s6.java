package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 09-02-2016.
 */
public class s6 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s6_layout);

        ListView s6 = (ListView) findViewById(R.id.s6_layout);
        final String[] sub6 = {"12R601 POWER ELECTRONICS AND DRIVES","12R602 EMBEDDED AND REAL-TIME SYSTEMS","12R603 VISION SYSTEMS AND IMAGE PROCESSING","12R604 AUTOMATION SYSTEM DESIGN","12Z070 ECONOMICS FOR ENGINEERS","12R610 POWER ELECTRONICS AND DRIVES LABORATORY","12R611 AUTOMATION SYSTEM DESIGN LABORATORY","12R620 INDUSTRIAL CUM LECTURE"};

        ArrayAdapter<String> adapter6 = new ArrayAdapter<String>(s6.this, android.R.layout.simple_list_item_1, sub6);

        s6.setAdapter(adapter6);
        
        s6.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0)
                {
                    Intent intent = new Intent(s6.this,s61.class);
                    startActivity(intent);
                }
                if(position == 1)
                {
                    Intent intent = new Intent(s6.this,s62.class);
                    startActivity(intent);
                }
                if(position == 2)
                {
                    Intent intent = new Intent(s6.this,s63.class);
                    startActivity(intent);
                }
                if(position == 3)
                {
                    Intent intent = new Intent(s6.this,s64.class);
                    startActivity(intent);
                }
                if(position == 4)
                {
                    Intent intent = new Intent(s6.this,s65.class);
                    startActivity(intent);
                }
                if(position == 5)
                {
                    Intent intent = new Intent(s6.this,s66.class);
                    startActivity(intent);
                }
                if(position == 6)
                {
                    Intent intent = new Intent(s6.this,s67.class);
                    startActivity(intent);
                }
                /*if(position == 7)
                {
                    Intent intent = new Intent(s6.this,s68.class);
                    startActivity(intent);
                }*/

            }
        });
    }
}