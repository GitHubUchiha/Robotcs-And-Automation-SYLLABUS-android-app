package com.example.karthikeyan.psgsyllabi_rae;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Karthikeyan on 20-02-2016.
 */
public class s513 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s513_layout);

        ListView s513 = (ListView) findViewById(R.id.s513_layout);
        final String[] topic = {"Statement of an optimization problems", "classification of optimization problem" , "classical optimization techniques :", "Single variable optimizations", "multi variable optimization", "equality constraints", "Inequality constraints", "No constraints"};

        ArrayAdapter<String> adapter31 = new ArrayAdapter<String>(s513.this, android.R.layout.simple_list_item_1, topic);

        s513.setAdapter(adapter31);

    }
}